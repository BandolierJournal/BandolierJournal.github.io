rm -rf bullet
