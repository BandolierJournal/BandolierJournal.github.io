/*jshint node: true, esversion: 6*/
'use strict';

const bulletApp = angular.module('bulletApp', ['ui.router', 'ui.bootstrap', 'ngSanitize']);


bulletApp.config(function($urlRouterProvider) {
        $urlRouterProvider.otherwise('/landing');
    })
    .run(function($window, $rootScope) {
        /* Connection Status Detection and Update */
        $rootScope.online = navigator.onLine;

        $window.addEventListener("offline", function() {
            $rootScope.$apply(function() {
                $rootScope.online = false;
            });
        }, false);

        $window.addEventListener("online", function() {
            $rootScope.$apply(function() {
                $rootScope.online = true;
            });
        }, false);
    });

bulletApp.directive('contenteditable', function ($sanitize) {
  return {
    restrict: 'A',
    require: '?ngModel',
    link: function (scope, element, attrs, ngModel) {
      if (!ngModel) return;
      function read() {
        ngModel.$setViewValue(element.html());
      }
      ngModel.$render = function () {
        var sanitary = $sanitize(ngModel.$viewValue || '');
        element.html(sanitary);
      };
      element.bind('blur keyup change', function () {
        scope.$apply(read);
      });
    }
  };
});


bulletApp.directive('eatClick', function () {
  return {
    restrict: 'A',
    link: function (scope, element) {
      element.on('click', function () {
        return false;
      });
    }
  };
});

bulletApp.factory('currentStates', function ($rootScope) {
  var currentStates = {
    daily: null,
    month: null,
    future: null,
    generic: null,
    genericTitle: false
  }
  $rootScope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams){
    currentStates[toState.name] = toParams;
    // These are useful for testing
    // console.log('ts', toState);
    // console.log('tp', toParams);
    // console.log('fs', fromState);
    // console.log('fp', fromParams);
  });

  $rootScope.$on('nameChange', function(event, collection) {
    if (currentStates.generic.id===collection.id) currentStates.genericTitle = collection.title;
  });

  $rootScope.$on('pageChange', function(event, args){
    if (args.type === 'month') currentStates.future = {index: args.index};
    if (args.type === 'day') currentStates.daily = {index: args.index};
  });

  //This console logs if there are errors in a state change
  $rootScope.$on('$stateChangeError', function(event, toState, toParams, fromState, fromParams){
    // console.log('err', event);
    // console.log('ts', toState);
    // console.log('tp', toParams);
    // console.log('fs', fromState);
    // console.log('fp', fromParams);
  });


  return currentStates
})

bulletApp.factory('DateFactory', function() {
    let today = Moment().startOf('day').toISOString(); // TODO: make this a function (so today is always up to date)
    let yesterday = Moment(today).subtract(1, 'days').toISOString();
    let thisMonth = Moment().startOf('month').toISOString();

    function splitCollections(collections) {
        if (!collections.length) return [
            [],
            []
        ];
        let last = (collections[0].type === "day") ? yesterday : lastMonth();
        let split = _.partition(collections, function(c) {
            return c.title < last;
        })
        let aged = split[0].sort(chronoSort);
        let future = split[1];
        return [aged, future];
    }

    function chronoSort(a, b) {
        return new Date(a.title) - new Date(b.title);
    }

    function roundDate(date, type) {
        type = type || 'day'; // or month
        return Moment(date).startOf(type).toISOString();
    }

    function display(offset, type) { //offset from today
        let display = [];
        let current = (type === 'day') ? today : thisMonth;
        for (let i = 1; i > -5; i--) {
            display.push(Moment(current).subtract(i - offset, type + 's').toISOString());
        }
        if (type === 'month') type = 'future';
        return display.map((e, index) => new Collection({
            title: e,
            type: type,
            id: Moment().add(index, 'milliseconds').toISOString()
        }));
    }


    function monthCal(month) {
        month = new Date(month);
        let day = month;
        let dayArray = [];
        while (day.getMonth() == month.getMonth()) {
            dayArray.push(day.toISOString());
            day = Moment(day).add(1, 'days').toISOString();
            day = new Date(day);
        }
        return dayArray;
    }

    function getChoices(input) {
        let [month, day, year] = input.split(' ');
        let choices = [];
        if (!day) choices = Moment.months()
        else if (!year) {
            for (let y of nextNYears(10)) {
                choices.push(`${month} ${y}`);
            }
            choices = [
                ...monthCal(Moment().month(month).startOf('month'))
                .map(d => `${month} ${Moment(d).date()}`),
                ...choices
            ];
        } else {
            for (let y of nextNYears(10)) {
                choices.push(`${month} ${day} ${y}`);
            }
        }
        return choices;
    }

    function convertDate(dateInput) {
        let [month, day, year] = dateInput.split(' ');
        let date = Moment().month(month);
        let type = 'day';

        if (!year) {
            if (day < 32) date = date.date(day);
            else [date, type] = [roundDate(date.year(day), 'month'), 'future']
        } else date = date.date(day).year(year);
        return [roundDate(date), type];
    }

    function getWeekday(date) {
        let weekday = Moment(date).isoWeekday();
        weekday = Moment().isoWeekday(weekday).format('dddd')
        return weekday;
    }

    function lastMonth(currentMonth) {
        currentMonth = currentMonth || thisMonth
        return Moment(currentMonth).subtract(1, 'month').toISOString()
    }

    function nextMonth(currentMonth) {
        currentMonth = currentMonth || thisMonth
        return Moment(currentMonth).add(1, 'month').toISOString()
    }

    function diffs(a, b, type) {
        var a = Moment(a);
        var b = Moment(b);
        return a.diff(b, type+'s');
    }

    function* nextNYears(n) {
        let i = 0;
        const thisYear = Moment(thisMonth).year();
        while (i < n) {
            yield thisYear + i;
            i++;
        }
    }

    function addOne(date, type) {
        return Moment(date).add(1, type).toISOString()
    }


    return {
        display: display,
        roundDate: roundDate,
        monthCal: monthCal,
        splitCollections: splitCollections,
        getChoices: getChoices,
        convertDate: convertDate,
        today: today,
        yesterday: yesterday,
        thisMonth: thisMonth,
        lastMonth: lastMonth,
        nextMonth: nextMonth,
        getWeekday: getWeekday,
        nextNYears: nextNYears,
        diffs: diffs,
        addOne: addOne,
        chronoSort: chronoSort
    }
})

bulletApp.filter('slice', function() {
  return function(arr, start, end) {
    return (arr || []).slice(start, end);
  };
});
bulletApp.filter('stateName', function () {
  return function(input) {
    var output;
    switch(input) {
      case 'day':
        output = 'daily';
        break;
      case 'month':
        output = 'month';
        break;
      case 'month-cal':
        output = 'month';
        break;
      case 'future':
        output = 'future';
        break;
      case 'generic':
        output = 'generic';
        break;
      default:
        output = '';
        break;
    }
    return output
  }
})

bulletApp.filter('titleFormat', function (DateFactory) {
  return function(title, type) {
    if (!Moment(new Date(title)).isValid()) return title;

    var output;
    switch(type) {
      case 'day':
        output = DateFactory.getWeekday(title)+', '+Moment(title).format('MMMM D');
        break;
      case 'month':
        output = Moment(title).format('MMMM YYYY');
        break;
      case 'month-cal':
        output = Moment(title).format('MMMM')+' Calendar';
        break;
      case 'future':
        output = Moment(title).format('MMMM YYYY');
        break;
      default:
        output = title;
    }
    return output;
  }
})

bulletApp.filter('dateFormat', function (DateFactory) {
  return function(title, type) {
    
    if (!Moment(new Date(title)).isValid()) return title;

    var output;
    switch(type) {
      case 'day':
        output = Moment(title).format('MMM D');
        break;
      case 'month':
        output = Moment(title).format('MMMM YYYY');
        break;
      case 'month-cal':
        output = Moment(title).format('MMMM')+' Calendar';
        break;
      case 'future':
        output = Moment(title).format('MMMM');
        break;
      default:
        output = Moment(title).format('MMM d');
    }
    return output;
  }
})

bulletApp.directive('addCollection', function($state, $filter) {
    return {
        restrict: 'E',
        templateUrl: 'scripts/add-collection/add-collection-template.html',
        scope: {
            collectionType: '@'
        },
        link: function(scope) {
            scope.collectionType = scope.collectionType || 'generic';
            // TODO: Add validations to create collections for day, month, etc.
            // ^^ Incorporate this into Sabrina's date validations
            scope.createCollection = function(collectionName) {
                new Collection(collectionName, scope.collectionType)
                    .save()
                    .then(collection => $state.go($filter('stateName')(scope.collectionType), { id: collection.id }))
                    .then(() => {
                        scope.collectionName = null;
                    })
            }

            scope.templateUrl = 'scripts/add-collection/collection-form.html';
        }
    }
})

/*jshint esversion: 6*/

bulletApp.directive('collection', function($log, $rootScope, currentStates, DateFactory, $state) {
    return {
        restrict: 'E',
        templateUrl: 'scripts/collections/collection.template.html',
        scope: {
            collection: '=',
            noAdd: '=',
            monthTitle: '=',
            noTitle: '='
        },
        link: function(scope, element) {
            scope.title = scope.monthTitle ? 'Log' : scope.collection.title;
            if (!scope.noAdd) scope.collection.bullets.push(new Bullet.Task({ status: 'new' }));

            scope.go = function() {
                if (scope.collection.type==='future') $state.go('month', {search: scope.collection.title});
            }

            $rootScope.$on('update', function(event, next) {
                if (next.id===scope.collection.id) scope.collection.update().then(c => {
                    angular.extend(scope.collection, c[0]);
                    scope.$evalAsync();
                });
            })

            scope.removeBullet = function(bullet) {
                return scope.collection.removeBullet(bullet)
                    .then(function() {
                        if (bullet.id) {
                            scope.collection.bullets = scope.collection.bullets.filter(b => b.id !== bullet.id);
                        }
                    })
                    .catch($log.err);
            };

            scope.addBullet = function(bullet) {
                if (bullet.content && bullet.content.length > 0) {
                    return scope.collection.addBullet(bullet)
                        .then(function() {
                          scope.collection.bullets.push(new Bullet.Task({ status: 'new' }))
                          scope.$evalAsync()
                        })
                        .catch($log.err);
                };
            }

            scope.save = function() {
                scope.collection.save().then(() => scope.$evalAsync());
                $rootScope.$broadcast('nameChange', scope.collection);
            }

            element.on('keydown', function(e) {
                if (e.which === 13) {
                    e.preventDefault();
                    e.target.blur();
                }
            });

        }
    };
});

bulletApp.directive('datePicker', function (DateFactory) {
    return {
        restrict: 'E',
        templateUrl: 'scripts/datepicker/datepicker.template.html',
        link: function (scope) {
            scope.getDates = DateFactory.getChoices;
        }
    };
});

bulletApp.directive('footer', function(currentStates, $state) {
    return {
        restrict: 'E',
        templateUrl: 'scripts/footer/footer.template.html',
        link: function(scope) {
            scope.currentStates = currentStates;
            scope.lastMonth = function() {
                if (currentStates.month) $state.go('month', currentStates.month)
                else $state.go('month', { search: Moment().startOf('month').toISOString() }) //DateFactory.thisMonth.toISOString()
            };
            scope.lastDaily = function() {
                $state.go('daily', currentStates.daily)
            };
            scope.lastFuture = function() {
                $state.go('future', currentStates.future)
            };
            scope.lastGeneric = function() {
                $state.go('generic', currentStates.generic)
            };
        }
    };
});

bulletApp.controller('GenericCtrl', function($scope, collection, $state, $filter) {
    if (collection.type !=='generic') $state.go($filter('stateName')(collection.type), { search: collection.title });
    $scope.collection = collection;
});

bulletApp.config(function ($stateProvider) {

  $stateProvider.state('generic', {
    url: '/generic/:id/',
    templateUrl: 'scripts/generic/generic.template.html',
    controller: 'GenericCtrl',
    resolve: {
        collection: function($stateParams, currentStates, $state) { 
            return Collection.findOrReturn({id: $stateParams.id})
                .then(c => {
                    c = c[0];
                    if (!c.title) $state.go('index');
                    else currentStates.genericTitle = c.title;
                    return c;
                }); 
        }
    }
  });

});

bulletApp.directive('bullet', function(DateFactory, $timeout, $rootScope, $state) {
    return {
        restrict: 'E',
        templateUrl: 'scripts/bullets/bullet.template.html',
        scope: {
            bullet: '=',
            removeFn: '&',
            addFn: '&',
            collectionType: '='
        },
        link: function(scope, element, attrs) {

            scope.showButton = 0;
            scope.enableButton = false;
            scope.typeDict = typeDict;
            scope.hideIcon = (attrs.noIcon) ? true : false;

            scope.editable = function() {
                if (!scope.bullet.status) return true;
                return scope.bullet.status === "incomplete" || scope.bullet.status === "new";
            }

            scope.toggleScheduler = function() {
                let addType = (scope.collectionType==='day') ? 'days' : 'months';
                scope.scheduleDate = (!scope.bullet.date) ? new Date() : DateFactory.addOne(scope.bullet.date, addType);
                scope.showScheduler = !scope.showScheduler;
            }

            scope.templateUrl = 'scripts/bullets/type.template.html';
            scope.datepickerUrl = 'scripts/bullets/datepicker.template.html';

            scope.selectType = function(b, type) {
                delete scope.bullet.status;
                Object.assign(scope.bullet, new Bullet[type](b))
                Object.setPrototypeOf(scope.bullet, new Bullet[type](b).constructor.prototype)
                if (scope.bullet.content) scope.bullet.save().then(() => scope.$evalAsync())
            }

            scope.changeType = function(b, type) {
                delete scope.bullet.status;
                Object.assign(scope.bullet, new Bullet[type](b))
                Object.setPrototypeOf(scope.bullet, new Bullet[type](b).constructor.prototype)
                return scope.bullet
            }

            const OS = process.platform;

            scope.showButtonPanel = function(b) {
                return b.status === 'incomplete' &&
                    b.rev &&
                    scope.enableButtons;
            };

            scope.showScheduleButton = function(b) {
                return b.type !== 'Note';
            };

            scope.showMigrateButton = function(b) {
                return b.type === 'Task';
            };

            scope.migrate = function() {
                scope.bullet.migrate()
                    .then(res => {
                        scope.$evalAsync();
                    });
            };

            scope.options = {
                minMode: 'day',
                dateDisabled: disabled
            }

            function disabled(data) {
                var date = data.date,
                    mode = data.mode;
                let notSelf = (scope.collectionType==='day') ? (mode==='day') : (mode==='month');
                return (scope.collectionType!=='month') && notSelf && (date.toISOString()===scope.bullet.date);
            }

            scope.next = function() {
                if (scope.bullet.next) $state.go('generic', { id: scope.bullet.next.id });
            }

            scope.schedule = function(date, mode) {
                scope.bullet.date = DateFactory.roundDate(date, mode);
                scope.showScheduler = false;
                if (mode === 'month') mode = 'future';
                scope.bullet.schedule(scope.bullet.date, mode)
                    .then(res => {
                        $rootScope.$broadcast('update', res.bullets[0].next);
                        scope.$evalAsync();

                    });
            };

            function editBullet(e) {

                if (scope.bullet.status !== 'migrated' && scope.bullet.status !== 'scheduled') {

                    if (e.which === 68 && scope.bullet.type === 'Task') return scope.bullet.toggleDone();
                    // cmd-x cross out
                    if (e.which === 88 && scope.bullet.type === 'Task') return scope.bullet.toggleStrike();

                    if (scope.editable()) {
                        // cmd-t change to task
                        delete scope.bullet.status;
                        if (e.which === 84) scope.changeType(scope.bullet, 'Task');
                        // cmd-e change to event
                        if (e.which === 69) scope.changeType(scope.bullet, 'Event');
                        // cmd-n change to note
                        if (e.which === 78) scope.changeType(scope.bullet, 'Note');
                    }
                    // cmd-d toggle done for tasks

                }
                // cmd-del remove from collection
                if (e.which === 8) {
                    if (scope.bullet.rev) {
                        e.preventDefault();
                        scope.removeFn()
                            .then(() => {
                                scope.$evalAsync();
                            });
                    }
                }
            }

            element.on('keydown', function(e) {
                if (e.which !== 91) {
                    if (e.which === 13 || e.which === 9) {
                        e.preventDefault();
                        e.target.blur()
                        if (scope.bullet.content) {
                            $timeout(function() {
                                try {
                                    e.target.parentNode.parentNode.nextElementSibling.firstChild.children[1].focus()
                                } catch (e) {}
                            }, 200)
                        }
                    } else if ((OS === 'darwin' && e.metaKey) || (OS !== 'darwin' && e.ctrlKey)) {
                        let updatedBullet = editBullet(e);
                        if (updatedBullet) scope.bullet = updatedBullet;
                    } else if (scope.bullet.status === 'struck' || scope.bullet.status === 'complete') {
                        if (e.which !== 9) e.preventDefault();
                    }
                }
            });

            scope.save = function() {
                if (event && event.relatedTarget && event.relatedTarget.id === 'migrate') return;
                if (!scope.bullet.rev) scope.addFn();
                else scope.bullet.save();
                $timeout(function() {
                    scope.enableButtons = false;
                    scope.$evalAsync()
                }, 300)
            }

        }
    };
});

/*jshint esversion: 6*/
bulletApp.directive('bulletIcon', function($state, $filter) {
    return {
        restrict: 'E',
        templateUrl: 'scripts/bullets/icon.template.html',
        scope: {
            bullet: '='
        },
        link: function(scope, element) {

            scope.iconType = function() {
                let type;
                if (!scope.bullet.status) type = scope.bullet.type;
                else type = scope.bullet.status === 'incomplete' ? scope.bullet.type : scope.bullet.status;
                return typeDict[type];
            };

            scope.toggleDone = function() {
                if (scope.bullet.type === "Task") {
                    if (scope.bullet.status === "complete") scope.bullet.toggleStrike();
                    else scope.bullet.toggleDone();
                    scope.bullet.save();
                }
            };

            scope.next = function() {
                if (scope.bullet.next) $state.go('generic', { id: scope.bullet.next.id });
            }

        }
    };
});

bulletApp.controller('IndexCtrl', function($scope, collections, bullets, AuthFactory, DateFactory) {
    $scope.collections = collections.filter(col => (col.type === 'generic')&&!!col.title);

    if (collections.length) collections.push({type: 'month', title: DateFactory.roundDate(DateFactory.today, 'month')})
    else collections = [{type: 'month', title: DateFactory.roundDate(DateFactory.today, 'month')}]
    
    let months = _.uniqBy(collections.filter(col => col.type==='month' || col.type==='month-cal'), 'title');
    $scope.months = months.map(i => i.title).sort();

    $scope.typeDict = typeDict;

    $scope.deleteCollection = function(collection) {
        collection.delete()
            .then(() => {
                let idx = $scope.collections.indexOf(collection);
                $scope.collections.splice(idx, 1);
                $scope.$evalAsync();
            });
    }
});

bulletApp.config(function ($stateProvider) {

  $stateProvider.state('index', {
    url: '/index',
    templateUrl: 'scripts/index/index.template.html',
    controller: 'IndexCtrl',
    resolve: {
        collections: function() {
            return Collection.fetchAll();
        },
        bullets: function() {
            return Bullet.fetchAll('event');
        }
    }
  });

  $stateProvider.state('landing', {
    url: '/landing',
    templateUrl: 'scripts/index/landingpage.html',
    controller: 'LandingCtrl'
  })

});

bulletApp.controller('LandingCtrl', function($scope, $state, $timeout) {
	$timeout(function() {
		if ($state.current.name === 'landing') $state.go('index')
	}, 2500);
});

bulletApp.config(function($stateProvider) {

    $stateProvider.state('daily', {
        url: '/daily/:index/:search',
        templateUrl: 'scripts/log/log.template.html',
        controller: 'LogCtrl',
        resolve: {
            collections: function(DateFactory) {
                return Collection.fetchAll({ type: 'day' })
                    .then(DateFactory.splitCollections);
            },
            type: () => 'day'
        }
    });

});

bulletApp.config(function($stateProvider) {

    $stateProvider.state('future', {
        url: '/future/:index/:search',
        templateUrl: 'scripts/log/log.template.html',
        controller: 'LogCtrl',
        resolve: {
            collections: function(DateFactory, $log) {
                return Collection.fetchAll({ type: 'future' })
                    .then(DateFactory.splitCollections)
                    .catch($log.err);
            },
            type: () => 'month'
        }
    });

});

bulletApp.controller('LogCtrl', function($scope, collections, DateFactory, type, $rootScope, $stateParams) {

    const aged = collections[0];
    const future = collections[1];
    let index = aged.length;

    new6(0);

    if ($stateParams.search) {
        let search = $stateParams.search;
        let diff = DateFactory.diffs(search, DateFactory.yesterday, type);
        if (diff >= 0) search = index + diff;
        else {
            search = aged.find(i => i.title === search);
            if (!search) {
                search = DateFactory.display(diff, type)[0];
                aged.push(search);
                aged.sort(DateFactory.chronoSort);
            }
            search = aged.indexOf(search);
        }
        index = findIndex(search);
        function findIndex(i) {
            return aged.length - Math.ceil((aged.length - i) / 6) * 6;
        }
        
    } else if ($stateParams.index) index = +$stateParams.index;
    if (index < 0) $scope.collections = aged.slice(0, index + 6);
    else navigate();

    function new6(offset) {
        $scope.collections = [];

        DateFactory.display(offset, type).forEach((c) => {
            let use = future.find(el => el.title === c.title) || c;
            $scope.collections.push(use);
        });
    }

    $scope.title = ((type === 'day') ? 'DAILY' : 'FUTURE') + ' LOG';

    $scope.prev6 = function() {
        if (index <= 0) return;
        if (index < 6) {
            $scope.collections = aged.slice(0, index);
            index -= 6;
            $rootScope.$broadcast('pageChange', { index: index, type: type })
        } else {
            index -= 6;
            navigate();
        }
    }

    $scope.next6 = function() {
        index += 6;
        navigate();
    }

    function navigate() {
        $rootScope.$broadcast('pageChange', { index: index, type: type })
        if (index >= aged.length) new6(index - aged.length);
        else $scope.collections = aged.slice(index, index + 6);
    }

});

/*jshint esversion: 6*/
bulletApp.directive('monthCal', function($log, $state) {
    return {
        restrict: 'E',
        templateUrl: 'scripts/month-cal/month.cal.template.html',
        scope: {
            collection: '=',
            days: '=',
        },
        link: function(scope) {
            scope.formattedTitle = 'Calendar'; //Moment(scope.collection.title).format('MMMM YYYY').toUpperCase();

            generateBulletList()

            function generateBulletList () {
              scope.bulletList = scope.days.map(day => {
                  return scope.collection.bullets.find(bullet => bullet.date === day) || new Bullet.Event({
                      date: day
                  });
              })
            }

            scope.removeBullet = function(bullet) {
                return scope.collection.removeBullet(bullet)
                .then(() => {
                  if (bullet.id) {
                    generateBulletList()
                  }
                  scope.$evalAsync()
                })
                .catch($log.err);
            };

            scope.addBullet = function(bullet) {
                if (bullet.content && bullet.content.length > 0) {
                    scope.collection.addMovedBullet(bullet);
                };
            }
        }
    };
});

/*jshint esversion: 6*/

bulletApp.controller('MonthlyTrackerCtrl', function ($scope, collections, DateFactory, month, $state) {

    $scope.daysInMonth = DateFactory.monthCal(month);
    $scope.month = month;
    $scope.log = collections.find(i => i.type === "month") || new Collection(month, 'month');
    $scope.cal = collections.find(i => i.type === "month-cal") || new Collection(month, 'month-cal');
    $scope.future = collections.find(i => i.type === "future") || new Collection(month, 'future');

    //
    $scope.nextMonth = function() {
      $state.go($state.current, {search: DateFactory.nextMonth($scope.month)})
    }
    $scope.lastMonth = function() {
      $state.go($state.current, {search: DateFactory.lastMonth($scope.month)})
    }
});

bulletApp.config(function($stateProvider) {
  $stateProvider.state('month', {
    url: '/month/:search',
    templateUrl: 'scripts/monthlytracker/monthlytracker.template.html',
    controller: 'MonthlyTrackerCtrl',
    resolve: {
      collections: function($stateParams, DateFactory) {
        const monthString = $stateParams.search || DateFactory.roundMonth(new Date).toISOString();
        return Collection.fetchAll({title: monthString});
      },
      month: function($stateParams, DateFactory) {
        return $stateParams.search || DateFactory.thisMonth;
      }
    }
  })
})

bulletApp.directive('refresh', function($state, $rootScope, AuthFactory){
    return {
        restrict: 'A',
        link: function(scope, element) {

            remoteDB.getSession()
            .then(res => {
                const username = res.userCtx.name;
                if(username) {
                    $rootScope.$apply(function(){
                        $rootScope.user = username;
                    });
                    AuthFactory.syncDB(username)
                }
            })
            .catch(console.error.bind(console))

            scope.syncing = function() {
                return $rootScope.sync;
            };

            scope.login = function() {
                if(!$rootScope.user) $state.go('signup');
            };
        }
    };
});

bulletApp.directive('searchBar', function(currentStates, $state, $log, $filter) {
    return {
        restrict: 'E',
        templateUrl: 'scripts/search/search.template.html',
        link: function(scope, element) {
            let fetched;

            scope.getBullets = function(search) {
                if (fetched) return fetched.filter(b => b.content.includes(search));
                return Bullet.fetchWithCollections(search)
                    .then(b => {
                        fetched = b;
                        return fetched;
                    }); 
            }

            scope.go = function(item) {
                if (item.collections.length) {
                    let collection = item.collections[0];
                    if (collection.type==='generic') $state.go('generic', {id: collection.id});
                    else $state.go($filter('stateName')(collection.type), { search: collection.title })
                }
                else $state.go('index');
                fetched = null;
                scope.select = null;
            }

            element.on('keydown', function(e) {
                if (e.which===27 || e.which===8) {
                    fetched = null;
                }
            })

        }
    };
});

/*jshint node:true, esversion:6*/
bulletApp.factory('AuthFactory', function ($state, $rootScope, $timeout) {

    const Auth = {};

    function createUserDB(user, verb) {
        let username = user.email.split('@')[0];
        return remoteDB[verb](username, user.password)
            .then(res => {
                console.log(res);
                return verb === 'signup' ? Auth.login(user) : res;
            })
            .then(res => {
                $rootScope.$apply(function(){
                    $rootScope.user = res.name;
                });
                console.log(Auth.syncDB(username));
                $state.go('index')
            })
            .catch(err => console.error("Couldn't signin: ", err));
    }

    Auth.syncDB = function(username) {
        remoteDB = new PouchDB(remoteDBAddress + userDBUrl(username), {
            skipSetup: true
        });
        remoteDB.compact();
        return db.sync(remoteDB, {
                live: true,
                retry: true
            })
            .on('active', function () {
                $rootScope.$apply(function () {
                    $rootScope.sync = true;
                })
            })
            .on('paused', function () {
                $timeout(function() {
                    $rootScope.sync = false;
                }, 500);
            });
    }

    Auth.login = function (user) {
        return createUserDB(user, 'login');
    }

    Auth.signup = function (user) {
        return createUserDB(user, 'signup');
    }

    return Auth;
});

bulletApp.controller('signupCtrl', function($scope, AuthFactory){
    angular.extend($scope, AuthFactory);
});

bulletApp.config(function($stateProvider) {

    $stateProvider.state('signup', {
        url: '/signup',
        templateUrl: 'scripts/signup/signup.template.html',
        controller: 'signupCtrl'
    });

});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5qcyIsIl91dGlscy9jb250ZW50ZWRpdGFibGUuZGlyZWN0aXZlLmpzIiwiX3V0aWxzL2N1cnJlbnRzdGF0ZXMuZmFjdG9yeS5qcyIsIl91dGlscy9kYXRlLmZhY3RvcnkuanMiLCJfdXRpbHMvc2xpY2UuZmlsdGVyLmpzIiwiX3V0aWxzL3N0YXRlLm5hbWUuZmlsdGVyLmpzIiwiX3V0aWxzL3RpdGxlLmZpbHRlci5qcyIsImFkZC1jb2xsZWN0aW9uL2FkZC1jb2xsZWN0aW9uLWRpcmVjdGl2ZS5qcyIsImNvbGxlY3Rpb25zL2NvbGxlY3Rpb24uZGlyZWN0aXZlLmpzIiwiZGF0ZXBpY2tlci9kYXRlcGlja2VyLmRpcmVjdGl2ZS5qcyIsImZvb3Rlci9mb290ZXIuZGlyZWN0aXZlLmpzIiwiZ2VuZXJpYy9nZW5lcmljLmNvbnRyb2xsZXIuanMiLCJnZW5lcmljL2dlbmVyaWMuc3RhdGUuanMiLCJidWxsZXRzL2J1bGxldC5kaXJlY3RpdmUuanMiLCJidWxsZXRzL2ljb24uZGlyZWN0aXZlLmpzIiwiaW5kZXgvaW5kZXguY29udHJvbGxlci5qcyIsImluZGV4L2luZGV4LnN0YXRlLmpzIiwiaW5kZXgvbGFuZGluZ3BhZ2UuanMiLCJsb2cvZGFpbHkuc3RhdGUuanMiLCJsb2cvZnV0dXJlLnN0YXRlLmpzIiwibG9nL2xvZy5jb250cm9sbGVyLmpzIiwibW9udGgtY2FsL21vbnRoLmNhbC5kaXJlY3RpdmUuanMiLCJtb250aGx5dHJhY2tlci9tb250aGx5dHJhY2tlci5jb250cm9sbGVyLmpzIiwibW9udGhseXRyYWNrZXIvbW9udGhseXRyYWNrZXIuc3RhdGUuanMiLCJyZWZyZXNoL3JlZnJlc2hTdGF0dXMuZGlyZWN0aXZlLmpzIiwic2VhcmNoL3NlYXJjaC5kaXJlY3RpdmUuanMiLCJzaWdudXAvYXV0aC5mYWN0b3J5LmpzIiwic2lnbnVwL3NpZ251cC5jb250cm9sbGVyLmpzIiwic2lnbnVwL3NpZ251cC5zdGF0ZS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FDekJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUMvQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FDdENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQy9JQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FDSkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FDMUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQ2xEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQ3hCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQy9EQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQ1RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUN0QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQ0pBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQ3BCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQ2xLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUNoQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FDcEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQ3ZCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUNMQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FDaEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQ2pCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUNqRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FDekNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FDbEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUNoQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUMzQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUNwQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FDckRBO0FBQ0E7QUFDQTtBQUNBO0FDSEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoibWFpbi5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8qanNoaW50IG5vZGU6IHRydWUsIGVzdmVyc2lvbjogNiovXG4ndXNlIHN0cmljdCc7XG5cbmNvbnN0IGJ1bGxldEFwcCA9IGFuZ3VsYXIubW9kdWxlKCdidWxsZXRBcHAnLCBbJ3VpLnJvdXRlcicsICd1aS5ib290c3RyYXAnLCAnbmdTYW5pdGl6ZSddKTtcblxuXG5idWxsZXRBcHAuY29uZmlnKGZ1bmN0aW9uKCR1cmxSb3V0ZXJQcm92aWRlcikge1xuICAgICAgICAkdXJsUm91dGVyUHJvdmlkZXIub3RoZXJ3aXNlKCcvbGFuZGluZycpO1xuICAgIH0pXG4gICAgLnJ1bihmdW5jdGlvbigkd2luZG93LCAkcm9vdFNjb3BlKSB7XG4gICAgICAgIC8qIENvbm5lY3Rpb24gU3RhdHVzIERldGVjdGlvbiBhbmQgVXBkYXRlICovXG4gICAgICAgICRyb290U2NvcGUub25saW5lID0gbmF2aWdhdG9yLm9uTGluZTtcblxuICAgICAgICAkd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJvZmZsaW5lXCIsIGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgJHJvb3RTY29wZS4kYXBwbHkoZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgJHJvb3RTY29wZS5vbmxpbmUgPSBmYWxzZTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9LCBmYWxzZSk7XG5cbiAgICAgICAgJHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwib25saW5lXCIsIGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgJHJvb3RTY29wZS4kYXBwbHkoZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgJHJvb3RTY29wZS5vbmxpbmUgPSB0cnVlO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0sIGZhbHNlKTtcbiAgICB9KTtcbiIsImJ1bGxldEFwcC5kaXJlY3RpdmUoJ2NvbnRlbnRlZGl0YWJsZScsIGZ1bmN0aW9uICgkc2FuaXRpemUpIHtcbiAgcmV0dXJuIHtcbiAgICByZXN0cmljdDogJ0EnLFxuICAgIHJlcXVpcmU6ICc/bmdNb2RlbCcsXG4gICAgbGluazogZnVuY3Rpb24gKHNjb3BlLCBlbGVtZW50LCBhdHRycywgbmdNb2RlbCkge1xuICAgICAgaWYgKCFuZ01vZGVsKSByZXR1cm47XG4gICAgICBmdW5jdGlvbiByZWFkKCkge1xuICAgICAgICBuZ01vZGVsLiRzZXRWaWV3VmFsdWUoZWxlbWVudC5odG1sKCkpO1xuICAgICAgfVxuICAgICAgbmdNb2RlbC4kcmVuZGVyID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgc2FuaXRhcnkgPSAkc2FuaXRpemUobmdNb2RlbC4kdmlld1ZhbHVlIHx8ICcnKTtcbiAgICAgICAgZWxlbWVudC5odG1sKHNhbml0YXJ5KTtcbiAgICAgIH07XG4gICAgICBlbGVtZW50LmJpbmQoJ2JsdXIga2V5dXAgY2hhbmdlJywgZnVuY3Rpb24gKCkge1xuICAgICAgICBzY29wZS4kYXBwbHkocmVhZCk7XG4gICAgICB9KTtcbiAgICB9XG4gIH07XG59KTtcblxuXG5idWxsZXRBcHAuZGlyZWN0aXZlKCdlYXRDbGljaycsIGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuIHtcbiAgICByZXN0cmljdDogJ0EnLFxuICAgIGxpbms6IGZ1bmN0aW9uIChzY29wZSwgZWxlbWVudCkge1xuICAgICAgZWxlbWVudC5vbignY2xpY2snLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcbn0pO1xuIiwiYnVsbGV0QXBwLmZhY3RvcnkoJ2N1cnJlbnRTdGF0ZXMnLCBmdW5jdGlvbiAoJHJvb3RTY29wZSkge1xuICB2YXIgY3VycmVudFN0YXRlcyA9IHtcbiAgICBkYWlseTogbnVsbCxcbiAgICBtb250aDogbnVsbCxcbiAgICBmdXR1cmU6IG51bGwsXG4gICAgZ2VuZXJpYzogbnVsbCxcbiAgICBnZW5lcmljVGl0bGU6IGZhbHNlXG4gIH1cbiAgJHJvb3RTY29wZS4kb24oJyRzdGF0ZUNoYW5nZVN1Y2Nlc3MnLCBmdW5jdGlvbihldmVudCwgdG9TdGF0ZSwgdG9QYXJhbXMsIGZyb21TdGF0ZSwgZnJvbVBhcmFtcyl7XG4gICAgY3VycmVudFN0YXRlc1t0b1N0YXRlLm5hbWVdID0gdG9QYXJhbXM7XG4gICAgLy8gVGhlc2UgYXJlIHVzZWZ1bCBmb3IgdGVzdGluZ1xuICAgIC8vIGNvbnNvbGUubG9nKCd0cycsIHRvU3RhdGUpO1xuICAgIC8vIGNvbnNvbGUubG9nKCd0cCcsIHRvUGFyYW1zKTtcbiAgICAvLyBjb25zb2xlLmxvZygnZnMnLCBmcm9tU3RhdGUpO1xuICAgIC8vIGNvbnNvbGUubG9nKCdmcCcsIGZyb21QYXJhbXMpO1xuICB9KTtcblxuICAkcm9vdFNjb3BlLiRvbignbmFtZUNoYW5nZScsIGZ1bmN0aW9uKGV2ZW50LCBjb2xsZWN0aW9uKSB7XG4gICAgaWYgKGN1cnJlbnRTdGF0ZXMuZ2VuZXJpYy5pZD09PWNvbGxlY3Rpb24uaWQpIGN1cnJlbnRTdGF0ZXMuZ2VuZXJpY1RpdGxlID0gY29sbGVjdGlvbi50aXRsZTtcbiAgfSk7XG5cbiAgJHJvb3RTY29wZS4kb24oJ3BhZ2VDaGFuZ2UnLCBmdW5jdGlvbihldmVudCwgYXJncyl7XG4gICAgaWYgKGFyZ3MudHlwZSA9PT0gJ21vbnRoJykgY3VycmVudFN0YXRlcy5mdXR1cmUgPSB7aW5kZXg6IGFyZ3MuaW5kZXh9O1xuICAgIGlmIChhcmdzLnR5cGUgPT09ICdkYXknKSBjdXJyZW50U3RhdGVzLmRhaWx5ID0ge2luZGV4OiBhcmdzLmluZGV4fTtcbiAgfSk7XG5cbiAgLy9UaGlzIGNvbnNvbGUgbG9ncyBpZiB0aGVyZSBhcmUgZXJyb3JzIGluIGEgc3RhdGUgY2hhbmdlXG4gICRyb290U2NvcGUuJG9uKCckc3RhdGVDaGFuZ2VFcnJvcicsIGZ1bmN0aW9uKGV2ZW50LCB0b1N0YXRlLCB0b1BhcmFtcywgZnJvbVN0YXRlLCBmcm9tUGFyYW1zKXtcbiAgICAvLyBjb25zb2xlLmxvZygnZXJyJywgZXZlbnQpO1xuICAgIC8vIGNvbnNvbGUubG9nKCd0cycsIHRvU3RhdGUpO1xuICAgIC8vIGNvbnNvbGUubG9nKCd0cCcsIHRvUGFyYW1zKTtcbiAgICAvLyBjb25zb2xlLmxvZygnZnMnLCBmcm9tU3RhdGUpO1xuICAgIC8vIGNvbnNvbGUubG9nKCdmcCcsIGZyb21QYXJhbXMpO1xuICB9KTtcblxuXG4gIHJldHVybiBjdXJyZW50U3RhdGVzXG59KVxuIiwiYnVsbGV0QXBwLmZhY3RvcnkoJ0RhdGVGYWN0b3J5JywgZnVuY3Rpb24oKSB7XG4gICAgbGV0IHRvZGF5ID0gTW9tZW50KCkuc3RhcnRPZignZGF5JykudG9JU09TdHJpbmcoKTsgLy8gVE9ETzogbWFrZSB0aGlzIGEgZnVuY3Rpb24gKHNvIHRvZGF5IGlzIGFsd2F5cyB1cCB0byBkYXRlKVxuICAgIGxldCB5ZXN0ZXJkYXkgPSBNb21lbnQodG9kYXkpLnN1YnRyYWN0KDEsICdkYXlzJykudG9JU09TdHJpbmcoKTtcbiAgICBsZXQgdGhpc01vbnRoID0gTW9tZW50KCkuc3RhcnRPZignbW9udGgnKS50b0lTT1N0cmluZygpO1xuXG4gICAgZnVuY3Rpb24gc3BsaXRDb2xsZWN0aW9ucyhjb2xsZWN0aW9ucykge1xuICAgICAgICBpZiAoIWNvbGxlY3Rpb25zLmxlbmd0aCkgcmV0dXJuIFtcbiAgICAgICAgICAgIFtdLFxuICAgICAgICAgICAgW11cbiAgICAgICAgXTtcbiAgICAgICAgbGV0IGxhc3QgPSAoY29sbGVjdGlvbnNbMF0udHlwZSA9PT0gXCJkYXlcIikgPyB5ZXN0ZXJkYXkgOiBsYXN0TW9udGgoKTtcbiAgICAgICAgbGV0IHNwbGl0ID0gXy5wYXJ0aXRpb24oY29sbGVjdGlvbnMsIGZ1bmN0aW9uKGMpIHtcbiAgICAgICAgICAgIHJldHVybiBjLnRpdGxlIDwgbGFzdDtcbiAgICAgICAgfSlcbiAgICAgICAgbGV0IGFnZWQgPSBzcGxpdFswXS5zb3J0KGNocm9ub1NvcnQpO1xuICAgICAgICBsZXQgZnV0dXJlID0gc3BsaXRbMV07XG4gICAgICAgIHJldHVybiBbYWdlZCwgZnV0dXJlXTtcbiAgICB9XG5cbiAgICBmdW5jdGlvbiBjaHJvbm9Tb3J0KGEsIGIpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBEYXRlKGEudGl0bGUpIC0gbmV3IERhdGUoYi50aXRsZSk7XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gcm91bmREYXRlKGRhdGUsIHR5cGUpIHtcbiAgICAgICAgdHlwZSA9IHR5cGUgfHwgJ2RheSc7IC8vIG9yIG1vbnRoXG4gICAgICAgIHJldHVybiBNb21lbnQoZGF0ZSkuc3RhcnRPZih0eXBlKS50b0lTT1N0cmluZygpO1xuICAgIH1cblxuICAgIGZ1bmN0aW9uIGRpc3BsYXkob2Zmc2V0LCB0eXBlKSB7IC8vb2Zmc2V0IGZyb20gdG9kYXlcbiAgICAgICAgbGV0IGRpc3BsYXkgPSBbXTtcbiAgICAgICAgbGV0IGN1cnJlbnQgPSAodHlwZSA9PT0gJ2RheScpID8gdG9kYXkgOiB0aGlzTW9udGg7XG4gICAgICAgIGZvciAobGV0IGkgPSAxOyBpID4gLTU7IGktLSkge1xuICAgICAgICAgICAgZGlzcGxheS5wdXNoKE1vbWVudChjdXJyZW50KS5zdWJ0cmFjdChpIC0gb2Zmc2V0LCB0eXBlICsgJ3MnKS50b0lTT1N0cmluZygpKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodHlwZSA9PT0gJ21vbnRoJykgdHlwZSA9ICdmdXR1cmUnO1xuICAgICAgICByZXR1cm4gZGlzcGxheS5tYXAoKGUsIGluZGV4KSA9PiBuZXcgQ29sbGVjdGlvbih7XG4gICAgICAgICAgICB0aXRsZTogZSxcbiAgICAgICAgICAgIHR5cGU6IHR5cGUsXG4gICAgICAgICAgICBpZDogTW9tZW50KCkuYWRkKGluZGV4LCAnbWlsbGlzZWNvbmRzJykudG9JU09TdHJpbmcoKVxuICAgICAgICB9KSk7XG4gICAgfVxuXG5cbiAgICBmdW5jdGlvbiBtb250aENhbChtb250aCkge1xuICAgICAgICBtb250aCA9IG5ldyBEYXRlKG1vbnRoKTtcbiAgICAgICAgbGV0IGRheSA9IG1vbnRoO1xuICAgICAgICBsZXQgZGF5QXJyYXkgPSBbXTtcbiAgICAgICAgd2hpbGUgKGRheS5nZXRNb250aCgpID09IG1vbnRoLmdldE1vbnRoKCkpIHtcbiAgICAgICAgICAgIGRheUFycmF5LnB1c2goZGF5LnRvSVNPU3RyaW5nKCkpO1xuICAgICAgICAgICAgZGF5ID0gTW9tZW50KGRheSkuYWRkKDEsICdkYXlzJykudG9JU09TdHJpbmcoKTtcbiAgICAgICAgICAgIGRheSA9IG5ldyBEYXRlKGRheSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGRheUFycmF5O1xuICAgIH1cblxuICAgIGZ1bmN0aW9uIGdldENob2ljZXMoaW5wdXQpIHtcbiAgICAgICAgbGV0IFttb250aCwgZGF5LCB5ZWFyXSA9IGlucHV0LnNwbGl0KCcgJyk7XG4gICAgICAgIGxldCBjaG9pY2VzID0gW107XG4gICAgICAgIGlmICghZGF5KSBjaG9pY2VzID0gTW9tZW50Lm1vbnRocygpXG4gICAgICAgIGVsc2UgaWYgKCF5ZWFyKSB7XG4gICAgICAgICAgICBmb3IgKGxldCB5IG9mIG5leHROWWVhcnMoMTApKSB7XG4gICAgICAgICAgICAgICAgY2hvaWNlcy5wdXNoKGAke21vbnRofSAke3l9YCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjaG9pY2VzID0gW1xuICAgICAgICAgICAgICAgIC4uLm1vbnRoQ2FsKE1vbWVudCgpLm1vbnRoKG1vbnRoKS5zdGFydE9mKCdtb250aCcpKVxuICAgICAgICAgICAgICAgIC5tYXAoZCA9PiBgJHttb250aH0gJHtNb21lbnQoZCkuZGF0ZSgpfWApLFxuICAgICAgICAgICAgICAgIC4uLmNob2ljZXNcbiAgICAgICAgICAgIF07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBmb3IgKGxldCB5IG9mIG5leHROWWVhcnMoMTApKSB7XG4gICAgICAgICAgICAgICAgY2hvaWNlcy5wdXNoKGAke21vbnRofSAke2RheX0gJHt5fWApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBjaG9pY2VzO1xuICAgIH1cblxuICAgIGZ1bmN0aW9uIGNvbnZlcnREYXRlKGRhdGVJbnB1dCkge1xuICAgICAgICBsZXQgW21vbnRoLCBkYXksIHllYXJdID0gZGF0ZUlucHV0LnNwbGl0KCcgJyk7XG4gICAgICAgIGxldCBkYXRlID0gTW9tZW50KCkubW9udGgobW9udGgpO1xuICAgICAgICBsZXQgdHlwZSA9ICdkYXknO1xuXG4gICAgICAgIGlmICgheWVhcikge1xuICAgICAgICAgICAgaWYgKGRheSA8IDMyKSBkYXRlID0gZGF0ZS5kYXRlKGRheSk7XG4gICAgICAgICAgICBlbHNlIFtkYXRlLCB0eXBlXSA9IFtyb3VuZERhdGUoZGF0ZS55ZWFyKGRheSksICdtb250aCcpLCAnZnV0dXJlJ11cbiAgICAgICAgfSBlbHNlIGRhdGUgPSBkYXRlLmRhdGUoZGF5KS55ZWFyKHllYXIpO1xuICAgICAgICByZXR1cm4gW3JvdW5kRGF0ZShkYXRlKSwgdHlwZV07XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gZ2V0V2Vla2RheShkYXRlKSB7XG4gICAgICAgIGxldCB3ZWVrZGF5ID0gTW9tZW50KGRhdGUpLmlzb1dlZWtkYXkoKTtcbiAgICAgICAgd2Vla2RheSA9IE1vbWVudCgpLmlzb1dlZWtkYXkod2Vla2RheSkuZm9ybWF0KCdkZGRkJylcbiAgICAgICAgcmV0dXJuIHdlZWtkYXk7XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gbGFzdE1vbnRoKGN1cnJlbnRNb250aCkge1xuICAgICAgICBjdXJyZW50TW9udGggPSBjdXJyZW50TW9udGggfHwgdGhpc01vbnRoXG4gICAgICAgIHJldHVybiBNb21lbnQoY3VycmVudE1vbnRoKS5zdWJ0cmFjdCgxLCAnbW9udGgnKS50b0lTT1N0cmluZygpXG4gICAgfVxuXG4gICAgZnVuY3Rpb24gbmV4dE1vbnRoKGN1cnJlbnRNb250aCkge1xuICAgICAgICBjdXJyZW50TW9udGggPSBjdXJyZW50TW9udGggfHwgdGhpc01vbnRoXG4gICAgICAgIHJldHVybiBNb21lbnQoY3VycmVudE1vbnRoKS5hZGQoMSwgJ21vbnRoJykudG9JU09TdHJpbmcoKVxuICAgIH1cblxuICAgIGZ1bmN0aW9uIGRpZmZzKGEsIGIsIHR5cGUpIHtcbiAgICAgICAgdmFyIGEgPSBNb21lbnQoYSk7XG4gICAgICAgIHZhciBiID0gTW9tZW50KGIpO1xuICAgICAgICByZXR1cm4gYS5kaWZmKGIsIHR5cGUrJ3MnKTtcbiAgICB9XG5cbiAgICBmdW5jdGlvbiogbmV4dE5ZZWFycyhuKSB7XG4gICAgICAgIGxldCBpID0gMDtcbiAgICAgICAgY29uc3QgdGhpc1llYXIgPSBNb21lbnQodGhpc01vbnRoKS55ZWFyKCk7XG4gICAgICAgIHdoaWxlIChpIDwgbikge1xuICAgICAgICAgICAgeWllbGQgdGhpc1llYXIgKyBpO1xuICAgICAgICAgICAgaSsrO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gYWRkT25lKGRhdGUsIHR5cGUpIHtcbiAgICAgICAgcmV0dXJuIE1vbWVudChkYXRlKS5hZGQoMSwgdHlwZSkudG9JU09TdHJpbmcoKVxuICAgIH1cblxuXG4gICAgcmV0dXJuIHtcbiAgICAgICAgZGlzcGxheTogZGlzcGxheSxcbiAgICAgICAgcm91bmREYXRlOiByb3VuZERhdGUsXG4gICAgICAgIG1vbnRoQ2FsOiBtb250aENhbCxcbiAgICAgICAgc3BsaXRDb2xsZWN0aW9uczogc3BsaXRDb2xsZWN0aW9ucyxcbiAgICAgICAgZ2V0Q2hvaWNlczogZ2V0Q2hvaWNlcyxcbiAgICAgICAgY29udmVydERhdGU6IGNvbnZlcnREYXRlLFxuICAgICAgICB0b2RheTogdG9kYXksXG4gICAgICAgIHllc3RlcmRheTogeWVzdGVyZGF5LFxuICAgICAgICB0aGlzTW9udGg6IHRoaXNNb250aCxcbiAgICAgICAgbGFzdE1vbnRoOiBsYXN0TW9udGgsXG4gICAgICAgIG5leHRNb250aDogbmV4dE1vbnRoLFxuICAgICAgICBnZXRXZWVrZGF5OiBnZXRXZWVrZGF5LFxuICAgICAgICBuZXh0TlllYXJzOiBuZXh0TlllYXJzLFxuICAgICAgICBkaWZmczogZGlmZnMsXG4gICAgICAgIGFkZE9uZTogYWRkT25lLFxuICAgICAgICBjaHJvbm9Tb3J0OiBjaHJvbm9Tb3J0XG4gICAgfVxufSlcbiIsImJ1bGxldEFwcC5maWx0ZXIoJ3NsaWNlJywgZnVuY3Rpb24oKSB7XG4gIHJldHVybiBmdW5jdGlvbihhcnIsIHN0YXJ0LCBlbmQpIHtcbiAgICByZXR1cm4gKGFyciB8fCBbXSkuc2xpY2Uoc3RhcnQsIGVuZCk7XG4gIH07XG59KTsiLCJidWxsZXRBcHAuZmlsdGVyKCdzdGF0ZU5hbWUnLCBmdW5jdGlvbiAoKSB7XG4gIHJldHVybiBmdW5jdGlvbihpbnB1dCkge1xuICAgIHZhciBvdXRwdXQ7XG4gICAgc3dpdGNoKGlucHV0KSB7XG4gICAgICBjYXNlICdkYXknOlxuICAgICAgICBvdXRwdXQgPSAnZGFpbHknO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ21vbnRoJzpcbiAgICAgICAgb3V0cHV0ID0gJ21vbnRoJztcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICdtb250aC1jYWwnOlxuICAgICAgICBvdXRwdXQgPSAnbW9udGgnO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ2Z1dHVyZSc6XG4gICAgICAgIG91dHB1dCA9ICdmdXR1cmUnO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ2dlbmVyaWMnOlxuICAgICAgICBvdXRwdXQgPSAnZ2VuZXJpYyc7XG4gICAgICAgIGJyZWFrO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgb3V0cHV0ID0gJyc7XG4gICAgICAgIGJyZWFrO1xuICAgIH1cbiAgICByZXR1cm4gb3V0cHV0XG4gIH1cbn0pXG4iLCJidWxsZXRBcHAuZmlsdGVyKCd0aXRsZUZvcm1hdCcsIGZ1bmN0aW9uIChEYXRlRmFjdG9yeSkge1xuICByZXR1cm4gZnVuY3Rpb24odGl0bGUsIHR5cGUpIHtcbiAgICBpZiAoIU1vbWVudChuZXcgRGF0ZSh0aXRsZSkpLmlzVmFsaWQoKSkgcmV0dXJuIHRpdGxlO1xuXG4gICAgdmFyIG91dHB1dDtcbiAgICBzd2l0Y2godHlwZSkge1xuICAgICAgY2FzZSAnZGF5JzpcbiAgICAgICAgb3V0cHV0ID0gRGF0ZUZhY3RvcnkuZ2V0V2Vla2RheSh0aXRsZSkrJywgJytNb21lbnQodGl0bGUpLmZvcm1hdCgnTU1NTSBEJyk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAnbW9udGgnOlxuICAgICAgICBvdXRwdXQgPSBNb21lbnQodGl0bGUpLmZvcm1hdCgnTU1NTSBZWVlZJyk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAnbW9udGgtY2FsJzpcbiAgICAgICAgb3V0cHV0ID0gTW9tZW50KHRpdGxlKS5mb3JtYXQoJ01NTU0nKSsnIENhbGVuZGFyJztcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICdmdXR1cmUnOlxuICAgICAgICBvdXRwdXQgPSBNb21lbnQodGl0bGUpLmZvcm1hdCgnTU1NTSBZWVlZJyk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgb3V0cHV0ID0gdGl0bGU7XG4gICAgfVxuICAgIHJldHVybiBvdXRwdXQ7XG4gIH1cbn0pXG5cbmJ1bGxldEFwcC5maWx0ZXIoJ2RhdGVGb3JtYXQnLCBmdW5jdGlvbiAoRGF0ZUZhY3RvcnkpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uKHRpdGxlLCB0eXBlKSB7XG4gICAgXG4gICAgaWYgKCFNb21lbnQobmV3IERhdGUodGl0bGUpKS5pc1ZhbGlkKCkpIHJldHVybiB0aXRsZTtcblxuICAgIHZhciBvdXRwdXQ7XG4gICAgc3dpdGNoKHR5cGUpIHtcbiAgICAgIGNhc2UgJ2RheSc6XG4gICAgICAgIG91dHB1dCA9IE1vbWVudCh0aXRsZSkuZm9ybWF0KCdNTU0gRCcpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ21vbnRoJzpcbiAgICAgICAgb3V0cHV0ID0gTW9tZW50KHRpdGxlKS5mb3JtYXQoJ01NTU0gWVlZWScpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ21vbnRoLWNhbCc6XG4gICAgICAgIG91dHB1dCA9IE1vbWVudCh0aXRsZSkuZm9ybWF0KCdNTU1NJykrJyBDYWxlbmRhcic7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAnZnV0dXJlJzpcbiAgICAgICAgb3V0cHV0ID0gTW9tZW50KHRpdGxlKS5mb3JtYXQoJ01NTU0nKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICBvdXRwdXQgPSBNb21lbnQodGl0bGUpLmZvcm1hdCgnTU1NIGQnKTtcbiAgICB9XG4gICAgcmV0dXJuIG91dHB1dDtcbiAgfVxufSlcbiIsImJ1bGxldEFwcC5kaXJlY3RpdmUoJ2FkZENvbGxlY3Rpb24nLCBmdW5jdGlvbigkc3RhdGUsICRmaWx0ZXIpIHtcbiAgICByZXR1cm4ge1xuICAgICAgICByZXN0cmljdDogJ0UnLFxuICAgICAgICB0ZW1wbGF0ZVVybDogJ3NjcmlwdHMvYWRkLWNvbGxlY3Rpb24vYWRkLWNvbGxlY3Rpb24tdGVtcGxhdGUuaHRtbCcsXG4gICAgICAgIHNjb3BlOiB7XG4gICAgICAgICAgICBjb2xsZWN0aW9uVHlwZTogJ0AnXG4gICAgICAgIH0sXG4gICAgICAgIGxpbms6IGZ1bmN0aW9uKHNjb3BlKSB7XG4gICAgICAgICAgICBzY29wZS5jb2xsZWN0aW9uVHlwZSA9IHNjb3BlLmNvbGxlY3Rpb25UeXBlIHx8ICdnZW5lcmljJztcbiAgICAgICAgICAgIC8vIFRPRE86IEFkZCB2YWxpZGF0aW9ucyB0byBjcmVhdGUgY29sbGVjdGlvbnMgZm9yIGRheSwgbW9udGgsIGV0Yy5cbiAgICAgICAgICAgIC8vIF5eIEluY29ycG9yYXRlIHRoaXMgaW50byBTYWJyaW5hJ3MgZGF0ZSB2YWxpZGF0aW9uc1xuICAgICAgICAgICAgc2NvcGUuY3JlYXRlQ29sbGVjdGlvbiA9IGZ1bmN0aW9uKGNvbGxlY3Rpb25OYW1lKSB7XG4gICAgICAgICAgICAgICAgbmV3IENvbGxlY3Rpb24oY29sbGVjdGlvbk5hbWUsIHNjb3BlLmNvbGxlY3Rpb25UeXBlKVxuICAgICAgICAgICAgICAgICAgICAuc2F2ZSgpXG4gICAgICAgICAgICAgICAgICAgIC50aGVuKGNvbGxlY3Rpb24gPT4gJHN0YXRlLmdvKCRmaWx0ZXIoJ3N0YXRlTmFtZScpKHNjb3BlLmNvbGxlY3Rpb25UeXBlKSwgeyBpZDogY29sbGVjdGlvbi5pZCB9KSlcbiAgICAgICAgICAgICAgICAgICAgLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2NvcGUuY29sbGVjdGlvbk5hbWUgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBzY29wZS50ZW1wbGF0ZVVybCA9ICdzY3JpcHRzL2FkZC1jb2xsZWN0aW9uL2NvbGxlY3Rpb24tZm9ybS5odG1sJztcbiAgICAgICAgfVxuICAgIH1cbn0pXG4iLCIvKmpzaGludCBlc3ZlcnNpb246IDYqL1xuXG5idWxsZXRBcHAuZGlyZWN0aXZlKCdjb2xsZWN0aW9uJywgZnVuY3Rpb24oJGxvZywgJHJvb3RTY29wZSwgY3VycmVudFN0YXRlcywgRGF0ZUZhY3RvcnksICRzdGF0ZSkge1xuICAgIHJldHVybiB7XG4gICAgICAgIHJlc3RyaWN0OiAnRScsXG4gICAgICAgIHRlbXBsYXRlVXJsOiAnc2NyaXB0cy9jb2xsZWN0aW9ucy9jb2xsZWN0aW9uLnRlbXBsYXRlLmh0bWwnLFxuICAgICAgICBzY29wZToge1xuICAgICAgICAgICAgY29sbGVjdGlvbjogJz0nLFxuICAgICAgICAgICAgbm9BZGQ6ICc9JyxcbiAgICAgICAgICAgIG1vbnRoVGl0bGU6ICc9JyxcbiAgICAgICAgICAgIG5vVGl0bGU6ICc9J1xuICAgICAgICB9LFxuICAgICAgICBsaW5rOiBmdW5jdGlvbihzY29wZSwgZWxlbWVudCkge1xuICAgICAgICAgICAgc2NvcGUudGl0bGUgPSBzY29wZS5tb250aFRpdGxlID8gJ0xvZycgOiBzY29wZS5jb2xsZWN0aW9uLnRpdGxlO1xuICAgICAgICAgICAgaWYgKCFzY29wZS5ub0FkZCkgc2NvcGUuY29sbGVjdGlvbi5idWxsZXRzLnB1c2gobmV3IEJ1bGxldC5UYXNrKHsgc3RhdHVzOiAnbmV3JyB9KSk7XG5cbiAgICAgICAgICAgIHNjb3BlLmdvID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgaWYgKHNjb3BlLmNvbGxlY3Rpb24udHlwZT09PSdmdXR1cmUnKSAkc3RhdGUuZ28oJ21vbnRoJywge3NlYXJjaDogc2NvcGUuY29sbGVjdGlvbi50aXRsZX0pO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAkcm9vdFNjb3BlLiRvbigndXBkYXRlJywgZnVuY3Rpb24oZXZlbnQsIG5leHQpIHtcbiAgICAgICAgICAgICAgICBpZiAobmV4dC5pZD09PXNjb3BlLmNvbGxlY3Rpb24uaWQpIHNjb3BlLmNvbGxlY3Rpb24udXBkYXRlKCkudGhlbihjID0+IHtcbiAgICAgICAgICAgICAgICAgICAgYW5ndWxhci5leHRlbmQoc2NvcGUuY29sbGVjdGlvbiwgY1swXSk7XG4gICAgICAgICAgICAgICAgICAgIHNjb3BlLiRldmFsQXN5bmMoKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pXG5cbiAgICAgICAgICAgIHNjb3BlLnJlbW92ZUJ1bGxldCA9IGZ1bmN0aW9uKGJ1bGxldCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBzY29wZS5jb2xsZWN0aW9uLnJlbW92ZUJ1bGxldChidWxsZXQpXG4gICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGJ1bGxldC5pZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNjb3BlLmNvbGxlY3Rpb24uYnVsbGV0cyA9IHNjb3BlLmNvbGxlY3Rpb24uYnVsbGV0cy5maWx0ZXIoYiA9PiBiLmlkICE9PSBidWxsZXQuaWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAuY2F0Y2goJGxvZy5lcnIpO1xuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgc2NvcGUuYWRkQnVsbGV0ID0gZnVuY3Rpb24oYnVsbGV0KSB7XG4gICAgICAgICAgICAgICAgaWYgKGJ1bGxldC5jb250ZW50ICYmIGJ1bGxldC5jb250ZW50Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHNjb3BlLmNvbGxlY3Rpb24uYWRkQnVsbGV0KGJ1bGxldClcbiAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBzY29wZS5jb2xsZWN0aW9uLmJ1bGxldHMucHVzaChuZXcgQnVsbGV0LlRhc2soeyBzdGF0dXM6ICduZXcnIH0pKVxuICAgICAgICAgICAgICAgICAgICAgICAgICBzY29wZS4kZXZhbEFzeW5jKClcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAuY2F0Y2goJGxvZy5lcnIpO1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHNjb3BlLnNhdmUgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICBzY29wZS5jb2xsZWN0aW9uLnNhdmUoKS50aGVuKCgpID0+IHNjb3BlLiRldmFsQXN5bmMoKSk7XG4gICAgICAgICAgICAgICAgJHJvb3RTY29wZS4kYnJvYWRjYXN0KCduYW1lQ2hhbmdlJywgc2NvcGUuY29sbGVjdGlvbik7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGVsZW1lbnQub24oJ2tleWRvd24nLCBmdW5jdGlvbihlKSB7XG4gICAgICAgICAgICAgICAgaWYgKGUud2hpY2ggPT09IDEzKSB7XG4gICAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQuYmx1cigpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgIH1cbiAgICB9O1xufSk7XG4iLCJidWxsZXRBcHAuZGlyZWN0aXZlKCdkYXRlUGlja2VyJywgZnVuY3Rpb24gKERhdGVGYWN0b3J5KSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgcmVzdHJpY3Q6ICdFJyxcbiAgICAgICAgdGVtcGxhdGVVcmw6ICdzY3JpcHRzL2RhdGVwaWNrZXIvZGF0ZXBpY2tlci50ZW1wbGF0ZS5odG1sJyxcbiAgICAgICAgbGluazogZnVuY3Rpb24gKHNjb3BlKSB7XG4gICAgICAgICAgICBzY29wZS5nZXREYXRlcyA9IERhdGVGYWN0b3J5LmdldENob2ljZXM7XG4gICAgICAgIH1cbiAgICB9O1xufSk7XG4iLCJidWxsZXRBcHAuZGlyZWN0aXZlKCdmb290ZXInLCBmdW5jdGlvbihjdXJyZW50U3RhdGVzLCAkc3RhdGUpIHtcbiAgICByZXR1cm4ge1xuICAgICAgICByZXN0cmljdDogJ0UnLFxuICAgICAgICB0ZW1wbGF0ZVVybDogJ3NjcmlwdHMvZm9vdGVyL2Zvb3Rlci50ZW1wbGF0ZS5odG1sJyxcbiAgICAgICAgbGluazogZnVuY3Rpb24oc2NvcGUpIHtcbiAgICAgICAgICAgIHNjb3BlLmN1cnJlbnRTdGF0ZXMgPSBjdXJyZW50U3RhdGVzO1xuICAgICAgICAgICAgc2NvcGUubGFzdE1vbnRoID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgaWYgKGN1cnJlbnRTdGF0ZXMubW9udGgpICRzdGF0ZS5nbygnbW9udGgnLCBjdXJyZW50U3RhdGVzLm1vbnRoKVxuICAgICAgICAgICAgICAgIGVsc2UgJHN0YXRlLmdvKCdtb250aCcsIHsgc2VhcmNoOiBNb21lbnQoKS5zdGFydE9mKCdtb250aCcpLnRvSVNPU3RyaW5nKCkgfSkgLy9EYXRlRmFjdG9yeS50aGlzTW9udGgudG9JU09TdHJpbmcoKVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHNjb3BlLmxhc3REYWlseSA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgICRzdGF0ZS5nbygnZGFpbHknLCBjdXJyZW50U3RhdGVzLmRhaWx5KVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHNjb3BlLmxhc3RGdXR1cmUgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAkc3RhdGUuZ28oJ2Z1dHVyZScsIGN1cnJlbnRTdGF0ZXMuZnV0dXJlKVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHNjb3BlLmxhc3RHZW5lcmljID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgJHN0YXRlLmdvKCdnZW5lcmljJywgY3VycmVudFN0YXRlcy5nZW5lcmljKVxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgIH07XG59KTtcbiIsImJ1bGxldEFwcC5jb250cm9sbGVyKCdHZW5lcmljQ3RybCcsIGZ1bmN0aW9uKCRzY29wZSwgY29sbGVjdGlvbiwgJHN0YXRlLCAkZmlsdGVyKSB7XG4gICAgaWYgKGNvbGxlY3Rpb24udHlwZSAhPT0nZ2VuZXJpYycpICRzdGF0ZS5nbygkZmlsdGVyKCdzdGF0ZU5hbWUnKShjb2xsZWN0aW9uLnR5cGUpLCB7IHNlYXJjaDogY29sbGVjdGlvbi50aXRsZSB9KTtcbiAgICAkc2NvcGUuY29sbGVjdGlvbiA9IGNvbGxlY3Rpb247XG59KTtcbiIsImJ1bGxldEFwcC5jb25maWcoZnVuY3Rpb24gKCRzdGF0ZVByb3ZpZGVyKSB7XG5cbiAgJHN0YXRlUHJvdmlkZXIuc3RhdGUoJ2dlbmVyaWMnLCB7XG4gICAgdXJsOiAnL2dlbmVyaWMvOmlkLycsXG4gICAgdGVtcGxhdGVVcmw6ICdzY3JpcHRzL2dlbmVyaWMvZ2VuZXJpYy50ZW1wbGF0ZS5odG1sJyxcbiAgICBjb250cm9sbGVyOiAnR2VuZXJpY0N0cmwnLFxuICAgIHJlc29sdmU6IHtcbiAgICAgICAgY29sbGVjdGlvbjogZnVuY3Rpb24oJHN0YXRlUGFyYW1zLCBjdXJyZW50U3RhdGVzLCAkc3RhdGUpIHsgXG4gICAgICAgICAgICByZXR1cm4gQ29sbGVjdGlvbi5maW5kT3JSZXR1cm4oe2lkOiAkc3RhdGVQYXJhbXMuaWR9KVxuICAgICAgICAgICAgICAgIC50aGVuKGMgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjID0gY1swXTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFjLnRpdGxlKSAkc3RhdGUuZ28oJ2luZGV4Jyk7XG4gICAgICAgICAgICAgICAgICAgIGVsc2UgY3VycmVudFN0YXRlcy5nZW5lcmljVGl0bGUgPSBjLnRpdGxlO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYztcbiAgICAgICAgICAgICAgICB9KTsgXG4gICAgICAgIH1cbiAgICB9XG4gIH0pO1xuXG59KTtcbiIsImJ1bGxldEFwcC5kaXJlY3RpdmUoJ2J1bGxldCcsIGZ1bmN0aW9uKERhdGVGYWN0b3J5LCAkdGltZW91dCwgJHJvb3RTY29wZSwgJHN0YXRlKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgcmVzdHJpY3Q6ICdFJyxcbiAgICAgICAgdGVtcGxhdGVVcmw6ICdzY3JpcHRzL2J1bGxldHMvYnVsbGV0LnRlbXBsYXRlLmh0bWwnLFxuICAgICAgICBzY29wZToge1xuICAgICAgICAgICAgYnVsbGV0OiAnPScsXG4gICAgICAgICAgICByZW1vdmVGbjogJyYnLFxuICAgICAgICAgICAgYWRkRm46ICcmJyxcbiAgICAgICAgICAgIGNvbGxlY3Rpb25UeXBlOiAnPSdcbiAgICAgICAgfSxcbiAgICAgICAgbGluazogZnVuY3Rpb24oc2NvcGUsIGVsZW1lbnQsIGF0dHJzKSB7XG5cbiAgICAgICAgICAgIHNjb3BlLnNob3dCdXR0b24gPSAwO1xuICAgICAgICAgICAgc2NvcGUuZW5hYmxlQnV0dG9uID0gZmFsc2U7XG4gICAgICAgICAgICBzY29wZS50eXBlRGljdCA9IHR5cGVEaWN0O1xuICAgICAgICAgICAgc2NvcGUuaGlkZUljb24gPSAoYXR0cnMubm9JY29uKSA/IHRydWUgOiBmYWxzZTtcblxuICAgICAgICAgICAgc2NvcGUuZWRpdGFibGUgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICBpZiAoIXNjb3BlLmJ1bGxldC5zdGF0dXMpIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgICAgIHJldHVybiBzY29wZS5idWxsZXQuc3RhdHVzID09PSBcImluY29tcGxldGVcIiB8fCBzY29wZS5idWxsZXQuc3RhdHVzID09PSBcIm5ld1wiO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBzY29wZS50b2dnbGVTY2hlZHVsZXIgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICBsZXQgYWRkVHlwZSA9IChzY29wZS5jb2xsZWN0aW9uVHlwZT09PSdkYXknKSA/ICdkYXlzJyA6ICdtb250aHMnO1xuICAgICAgICAgICAgICAgIHNjb3BlLnNjaGVkdWxlRGF0ZSA9ICghc2NvcGUuYnVsbGV0LmRhdGUpID8gbmV3IERhdGUoKSA6IERhdGVGYWN0b3J5LmFkZE9uZShzY29wZS5idWxsZXQuZGF0ZSwgYWRkVHlwZSk7XG4gICAgICAgICAgICAgICAgc2NvcGUuc2hvd1NjaGVkdWxlciA9ICFzY29wZS5zaG93U2NoZWR1bGVyO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBzY29wZS50ZW1wbGF0ZVVybCA9ICdzY3JpcHRzL2J1bGxldHMvdHlwZS50ZW1wbGF0ZS5odG1sJztcbiAgICAgICAgICAgIHNjb3BlLmRhdGVwaWNrZXJVcmwgPSAnc2NyaXB0cy9idWxsZXRzL2RhdGVwaWNrZXIudGVtcGxhdGUuaHRtbCc7XG5cbiAgICAgICAgICAgIHNjb3BlLnNlbGVjdFR5cGUgPSBmdW5jdGlvbihiLCB0eXBlKSB7XG4gICAgICAgICAgICAgICAgZGVsZXRlIHNjb3BlLmJ1bGxldC5zdGF0dXM7XG4gICAgICAgICAgICAgICAgT2JqZWN0LmFzc2lnbihzY29wZS5idWxsZXQsIG5ldyBCdWxsZXRbdHlwZV0oYikpXG4gICAgICAgICAgICAgICAgT2JqZWN0LnNldFByb3RvdHlwZU9mKHNjb3BlLmJ1bGxldCwgbmV3IEJ1bGxldFt0eXBlXShiKS5jb25zdHJ1Y3Rvci5wcm90b3R5cGUpXG4gICAgICAgICAgICAgICAgaWYgKHNjb3BlLmJ1bGxldC5jb250ZW50KSBzY29wZS5idWxsZXQuc2F2ZSgpLnRoZW4oKCkgPT4gc2NvcGUuJGV2YWxBc3luYygpKVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBzY29wZS5jaGFuZ2VUeXBlID0gZnVuY3Rpb24oYiwgdHlwZSkge1xuICAgICAgICAgICAgICAgIGRlbGV0ZSBzY29wZS5idWxsZXQuc3RhdHVzO1xuICAgICAgICAgICAgICAgIE9iamVjdC5hc3NpZ24oc2NvcGUuYnVsbGV0LCBuZXcgQnVsbGV0W3R5cGVdKGIpKVxuICAgICAgICAgICAgICAgIE9iamVjdC5zZXRQcm90b3R5cGVPZihzY29wZS5idWxsZXQsIG5ldyBCdWxsZXRbdHlwZV0oYikuY29uc3RydWN0b3IucHJvdG90eXBlKVxuICAgICAgICAgICAgICAgIHJldHVybiBzY29wZS5idWxsZXRcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY29uc3QgT1MgPSBwcm9jZXNzLnBsYXRmb3JtO1xuXG4gICAgICAgICAgICBzY29wZS5zaG93QnV0dG9uUGFuZWwgPSBmdW5jdGlvbihiKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGIuc3RhdHVzID09PSAnaW5jb21wbGV0ZScgJiZcbiAgICAgICAgICAgICAgICAgICAgYi5yZXYgJiZcbiAgICAgICAgICAgICAgICAgICAgc2NvcGUuZW5hYmxlQnV0dG9ucztcbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIHNjb3BlLnNob3dTY2hlZHVsZUJ1dHRvbiA9IGZ1bmN0aW9uKGIpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYi50eXBlICE9PSAnTm90ZSc7XG4gICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICBzY29wZS5zaG93TWlncmF0ZUJ1dHRvbiA9IGZ1bmN0aW9uKGIpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYi50eXBlID09PSAnVGFzayc7XG4gICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICBzY29wZS5taWdyYXRlID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgc2NvcGUuYnVsbGV0Lm1pZ3JhdGUoKVxuICAgICAgICAgICAgICAgICAgICAudGhlbihyZXMgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2NvcGUuJGV2YWxBc3luYygpO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIHNjb3BlLm9wdGlvbnMgPSB7XG4gICAgICAgICAgICAgICAgbWluTW9kZTogJ2RheScsXG4gICAgICAgICAgICAgICAgZGF0ZURpc2FibGVkOiBkaXNhYmxlZFxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBmdW5jdGlvbiBkaXNhYmxlZChkYXRhKSB7XG4gICAgICAgICAgICAgICAgdmFyIGRhdGUgPSBkYXRhLmRhdGUsXG4gICAgICAgICAgICAgICAgICAgIG1vZGUgPSBkYXRhLm1vZGU7XG4gICAgICAgICAgICAgICAgbGV0IG5vdFNlbGYgPSAoc2NvcGUuY29sbGVjdGlvblR5cGU9PT0nZGF5JykgPyAobW9kZT09PSdkYXknKSA6IChtb2RlPT09J21vbnRoJyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIChzY29wZS5jb2xsZWN0aW9uVHlwZSE9PSdtb250aCcpICYmIG5vdFNlbGYgJiYgKGRhdGUudG9JU09TdHJpbmcoKT09PXNjb3BlLmJ1bGxldC5kYXRlKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgc2NvcGUubmV4dCA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgIGlmIChzY29wZS5idWxsZXQubmV4dCkgJHN0YXRlLmdvKCdnZW5lcmljJywgeyBpZDogc2NvcGUuYnVsbGV0Lm5leHQuaWQgfSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHNjb3BlLnNjaGVkdWxlID0gZnVuY3Rpb24oZGF0ZSwgbW9kZSkge1xuICAgICAgICAgICAgICAgIHNjb3BlLmJ1bGxldC5kYXRlID0gRGF0ZUZhY3Rvcnkucm91bmREYXRlKGRhdGUsIG1vZGUpO1xuICAgICAgICAgICAgICAgIHNjb3BlLnNob3dTY2hlZHVsZXIgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICBpZiAobW9kZSA9PT0gJ21vbnRoJykgbW9kZSA9ICdmdXR1cmUnO1xuICAgICAgICAgICAgICAgIHNjb3BlLmJ1bGxldC5zY2hlZHVsZShzY29wZS5idWxsZXQuZGF0ZSwgbW9kZSlcbiAgICAgICAgICAgICAgICAgICAgLnRoZW4ocmVzID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICRyb290U2NvcGUuJGJyb2FkY2FzdCgndXBkYXRlJywgcmVzLmJ1bGxldHNbMF0ubmV4dCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzY29wZS4kZXZhbEFzeW5jKCk7XG5cbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICBmdW5jdGlvbiBlZGl0QnVsbGV0KGUpIHtcblxuICAgICAgICAgICAgICAgIGlmIChzY29wZS5idWxsZXQuc3RhdHVzICE9PSAnbWlncmF0ZWQnICYmIHNjb3BlLmJ1bGxldC5zdGF0dXMgIT09ICdzY2hlZHVsZWQnKSB7XG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKGUud2hpY2ggPT09IDY4ICYmIHNjb3BlLmJ1bGxldC50eXBlID09PSAnVGFzaycpIHJldHVybiBzY29wZS5idWxsZXQudG9nZ2xlRG9uZSgpO1xuICAgICAgICAgICAgICAgICAgICAvLyBjbWQteCBjcm9zcyBvdXRcbiAgICAgICAgICAgICAgICAgICAgaWYgKGUud2hpY2ggPT09IDg4ICYmIHNjb3BlLmJ1bGxldC50eXBlID09PSAnVGFzaycpIHJldHVybiBzY29wZS5idWxsZXQudG9nZ2xlU3RyaWtlKCk7XG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKHNjb3BlLmVkaXRhYmxlKCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNtZC10IGNoYW5nZSB0byB0YXNrXG4gICAgICAgICAgICAgICAgICAgICAgICBkZWxldGUgc2NvcGUuYnVsbGV0LnN0YXR1cztcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlLndoaWNoID09PSA4NCkgc2NvcGUuY2hhbmdlVHlwZShzY29wZS5idWxsZXQsICdUYXNrJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBjbWQtZSBjaGFuZ2UgdG8gZXZlbnRcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlLndoaWNoID09PSA2OSkgc2NvcGUuY2hhbmdlVHlwZShzY29wZS5idWxsZXQsICdFdmVudCcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gY21kLW4gY2hhbmdlIHRvIG5vdGVcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlLndoaWNoID09PSA3OCkgc2NvcGUuY2hhbmdlVHlwZShzY29wZS5idWxsZXQsICdOb3RlJyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgLy8gY21kLWQgdG9nZ2xlIGRvbmUgZm9yIHRhc2tzXG5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gY21kLWRlbCByZW1vdmUgZnJvbSBjb2xsZWN0aW9uXG4gICAgICAgICAgICAgICAgaWYgKGUud2hpY2ggPT09IDgpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHNjb3BlLmJ1bGxldC5yZXYpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNjb3BlLnJlbW92ZUZuKClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbigoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNjb3BlLiRldmFsQXN5bmMoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgZWxlbWVudC5vbigna2V5ZG93bicsIGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgICAgICAgICBpZiAoZS53aGljaCAhPT0gOTEpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGUud2hpY2ggPT09IDEzIHx8IGUud2hpY2ggPT09IDkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LmJsdXIoKVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNjb3BlLmJ1bGxldC5jb250ZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJHRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC5wYXJlbnROb2RlLnBhcmVudE5vZGUubmV4dEVsZW1lbnRTaWJsaW5nLmZpcnN0Q2hpbGQuY2hpbGRyZW5bMV0uZm9jdXMoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sIDIwMClcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmICgoT1MgPT09ICdkYXJ3aW4nICYmIGUubWV0YUtleSkgfHwgKE9TICE9PSAnZGFyd2luJyAmJiBlLmN0cmxLZXkpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgdXBkYXRlZEJ1bGxldCA9IGVkaXRCdWxsZXQoZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodXBkYXRlZEJ1bGxldCkgc2NvcGUuYnVsbGV0ID0gdXBkYXRlZEJ1bGxldDtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChzY29wZS5idWxsZXQuc3RhdHVzID09PSAnc3RydWNrJyB8fCBzY29wZS5idWxsZXQuc3RhdHVzID09PSAnY29tcGxldGUnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZS53aGljaCAhPT0gOSkgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIHNjb3BlLnNhdmUgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICBpZiAoZXZlbnQgJiYgZXZlbnQucmVsYXRlZFRhcmdldCAmJiBldmVudC5yZWxhdGVkVGFyZ2V0LmlkID09PSAnbWlncmF0ZScpIHJldHVybjtcbiAgICAgICAgICAgICAgICBpZiAoIXNjb3BlLmJ1bGxldC5yZXYpIHNjb3BlLmFkZEZuKCk7XG4gICAgICAgICAgICAgICAgZWxzZSBzY29wZS5idWxsZXQuc2F2ZSgpO1xuICAgICAgICAgICAgICAgICR0aW1lb3V0KGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgICAgICBzY29wZS5lbmFibGVCdXR0b25zID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgIHNjb3BlLiRldmFsQXN5bmMoKVxuICAgICAgICAgICAgICAgIH0sIDMwMClcbiAgICAgICAgICAgIH1cblxuICAgICAgICB9XG4gICAgfTtcbn0pO1xuIiwiLypqc2hpbnQgZXN2ZXJzaW9uOiA2Ki9cbmJ1bGxldEFwcC5kaXJlY3RpdmUoJ2J1bGxldEljb24nLCBmdW5jdGlvbigkc3RhdGUsICRmaWx0ZXIpIHtcbiAgICByZXR1cm4ge1xuICAgICAgICByZXN0cmljdDogJ0UnLFxuICAgICAgICB0ZW1wbGF0ZVVybDogJ3NjcmlwdHMvYnVsbGV0cy9pY29uLnRlbXBsYXRlLmh0bWwnLFxuICAgICAgICBzY29wZToge1xuICAgICAgICAgICAgYnVsbGV0OiAnPSdcbiAgICAgICAgfSxcbiAgICAgICAgbGluazogZnVuY3Rpb24oc2NvcGUsIGVsZW1lbnQpIHtcblxuICAgICAgICAgICAgc2NvcGUuaWNvblR5cGUgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICBsZXQgdHlwZTtcbiAgICAgICAgICAgICAgICBpZiAoIXNjb3BlLmJ1bGxldC5zdGF0dXMpIHR5cGUgPSBzY29wZS5idWxsZXQudHlwZTtcbiAgICAgICAgICAgICAgICBlbHNlIHR5cGUgPSBzY29wZS5idWxsZXQuc3RhdHVzID09PSAnaW5jb21wbGV0ZScgPyBzY29wZS5idWxsZXQudHlwZSA6IHNjb3BlLmJ1bGxldC5zdGF0dXM7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVEaWN0W3R5cGVdO1xuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgc2NvcGUudG9nZ2xlRG9uZSA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgIGlmIChzY29wZS5idWxsZXQudHlwZSA9PT0gXCJUYXNrXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHNjb3BlLmJ1bGxldC5zdGF0dXMgPT09IFwiY29tcGxldGVcIikgc2NvcGUuYnVsbGV0LnRvZ2dsZVN0cmlrZSgpO1xuICAgICAgICAgICAgICAgICAgICBlbHNlIHNjb3BlLmJ1bGxldC50b2dnbGVEb25lKCk7XG4gICAgICAgICAgICAgICAgICAgIHNjb3BlLmJ1bGxldC5zYXZlKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgc2NvcGUubmV4dCA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgIGlmIChzY29wZS5idWxsZXQubmV4dCkgJHN0YXRlLmdvKCdnZW5lcmljJywgeyBpZDogc2NvcGUuYnVsbGV0Lm5leHQuaWQgfSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgfVxuICAgIH07XG59KTtcbiIsImJ1bGxldEFwcC5jb250cm9sbGVyKCdJbmRleEN0cmwnLCBmdW5jdGlvbigkc2NvcGUsIGNvbGxlY3Rpb25zLCBidWxsZXRzLCBBdXRoRmFjdG9yeSwgRGF0ZUZhY3RvcnkpIHtcbiAgICAkc2NvcGUuY29sbGVjdGlvbnMgPSBjb2xsZWN0aW9ucy5maWx0ZXIoY29sID0+IChjb2wudHlwZSA9PT0gJ2dlbmVyaWMnKSYmISFjb2wudGl0bGUpO1xuXG4gICAgaWYgKGNvbGxlY3Rpb25zLmxlbmd0aCkgY29sbGVjdGlvbnMucHVzaCh7dHlwZTogJ21vbnRoJywgdGl0bGU6IERhdGVGYWN0b3J5LnJvdW5kRGF0ZShEYXRlRmFjdG9yeS50b2RheSwgJ21vbnRoJyl9KVxuICAgIGVsc2UgY29sbGVjdGlvbnMgPSBbe3R5cGU6ICdtb250aCcsIHRpdGxlOiBEYXRlRmFjdG9yeS5yb3VuZERhdGUoRGF0ZUZhY3RvcnkudG9kYXksICdtb250aCcpfV1cbiAgICBcbiAgICBsZXQgbW9udGhzID0gXy51bmlxQnkoY29sbGVjdGlvbnMuZmlsdGVyKGNvbCA9PiBjb2wudHlwZT09PSdtb250aCcgfHwgY29sLnR5cGU9PT0nbW9udGgtY2FsJyksICd0aXRsZScpO1xuICAgICRzY29wZS5tb250aHMgPSBtb250aHMubWFwKGkgPT4gaS50aXRsZSkuc29ydCgpO1xuXG4gICAgJHNjb3BlLnR5cGVEaWN0ID0gdHlwZURpY3Q7XG5cbiAgICAkc2NvcGUuZGVsZXRlQ29sbGVjdGlvbiA9IGZ1bmN0aW9uKGNvbGxlY3Rpb24pIHtcbiAgICAgICAgY29sbGVjdGlvbi5kZWxldGUoKVxuICAgICAgICAgICAgLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgIGxldCBpZHggPSAkc2NvcGUuY29sbGVjdGlvbnMuaW5kZXhPZihjb2xsZWN0aW9uKTtcbiAgICAgICAgICAgICAgICAkc2NvcGUuY29sbGVjdGlvbnMuc3BsaWNlKGlkeCwgMSk7XG4gICAgICAgICAgICAgICAgJHNjb3BlLiRldmFsQXN5bmMoKTtcbiAgICAgICAgICAgIH0pO1xuICAgIH1cbn0pO1xuIiwiYnVsbGV0QXBwLmNvbmZpZyhmdW5jdGlvbiAoJHN0YXRlUHJvdmlkZXIpIHtcblxuICAkc3RhdGVQcm92aWRlci5zdGF0ZSgnaW5kZXgnLCB7XG4gICAgdXJsOiAnL2luZGV4JyxcbiAgICB0ZW1wbGF0ZVVybDogJ3NjcmlwdHMvaW5kZXgvaW5kZXgudGVtcGxhdGUuaHRtbCcsXG4gICAgY29udHJvbGxlcjogJ0luZGV4Q3RybCcsXG4gICAgcmVzb2x2ZToge1xuICAgICAgICBjb2xsZWN0aW9uczogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICByZXR1cm4gQ29sbGVjdGlvbi5mZXRjaEFsbCgpO1xuICAgICAgICB9LFxuICAgICAgICBidWxsZXRzOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHJldHVybiBCdWxsZXQuZmV0Y2hBbGwoJ2V2ZW50Jyk7XG4gICAgICAgIH1cbiAgICB9XG4gIH0pO1xuXG4gICRzdGF0ZVByb3ZpZGVyLnN0YXRlKCdsYW5kaW5nJywge1xuICAgIHVybDogJy9sYW5kaW5nJyxcbiAgICB0ZW1wbGF0ZVVybDogJ3NjcmlwdHMvaW5kZXgvbGFuZGluZ3BhZ2UuaHRtbCcsXG4gICAgY29udHJvbGxlcjogJ0xhbmRpbmdDdHJsJ1xuICB9KVxuXG59KTtcbiIsImJ1bGxldEFwcC5jb250cm9sbGVyKCdMYW5kaW5nQ3RybCcsIGZ1bmN0aW9uKCRzY29wZSwgJHN0YXRlLCAkdGltZW91dCkge1xuXHQkdGltZW91dChmdW5jdGlvbigpIHtcblx0XHRpZiAoJHN0YXRlLmN1cnJlbnQubmFtZSA9PT0gJ2xhbmRpbmcnKSAkc3RhdGUuZ28oJ2luZGV4Jylcblx0fSwgMjUwMCk7XG59KTtcbiIsImJ1bGxldEFwcC5jb25maWcoZnVuY3Rpb24oJHN0YXRlUHJvdmlkZXIpIHtcblxuICAgICRzdGF0ZVByb3ZpZGVyLnN0YXRlKCdkYWlseScsIHtcbiAgICAgICAgdXJsOiAnL2RhaWx5LzppbmRleC86c2VhcmNoJyxcbiAgICAgICAgdGVtcGxhdGVVcmw6ICdzY3JpcHRzL2xvZy9sb2cudGVtcGxhdGUuaHRtbCcsXG4gICAgICAgIGNvbnRyb2xsZXI6ICdMb2dDdHJsJyxcbiAgICAgICAgcmVzb2x2ZToge1xuICAgICAgICAgICAgY29sbGVjdGlvbnM6IGZ1bmN0aW9uKERhdGVGYWN0b3J5KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIENvbGxlY3Rpb24uZmV0Y2hBbGwoeyB0eXBlOiAnZGF5JyB9KVxuICAgICAgICAgICAgICAgICAgICAudGhlbihEYXRlRmFjdG9yeS5zcGxpdENvbGxlY3Rpb25zKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB0eXBlOiAoKSA9PiAnZGF5J1xuICAgICAgICB9XG4gICAgfSk7XG5cbn0pO1xuIiwiYnVsbGV0QXBwLmNvbmZpZyhmdW5jdGlvbigkc3RhdGVQcm92aWRlcikge1xuXG4gICAgJHN0YXRlUHJvdmlkZXIuc3RhdGUoJ2Z1dHVyZScsIHtcbiAgICAgICAgdXJsOiAnL2Z1dHVyZS86aW5kZXgvOnNlYXJjaCcsXG4gICAgICAgIHRlbXBsYXRlVXJsOiAnc2NyaXB0cy9sb2cvbG9nLnRlbXBsYXRlLmh0bWwnLFxuICAgICAgICBjb250cm9sbGVyOiAnTG9nQ3RybCcsXG4gICAgICAgIHJlc29sdmU6IHtcbiAgICAgICAgICAgIGNvbGxlY3Rpb25zOiBmdW5jdGlvbihEYXRlRmFjdG9yeSwgJGxvZykge1xuICAgICAgICAgICAgICAgIHJldHVybiBDb2xsZWN0aW9uLmZldGNoQWxsKHsgdHlwZTogJ2Z1dHVyZScgfSlcbiAgICAgICAgICAgICAgICAgICAgLnRoZW4oRGF0ZUZhY3Rvcnkuc3BsaXRDb2xsZWN0aW9ucylcbiAgICAgICAgICAgICAgICAgICAgLmNhdGNoKCRsb2cuZXJyKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB0eXBlOiAoKSA9PiAnbW9udGgnXG4gICAgICAgIH1cbiAgICB9KTtcblxufSk7XG4iLCJidWxsZXRBcHAuY29udHJvbGxlcignTG9nQ3RybCcsIGZ1bmN0aW9uKCRzY29wZSwgY29sbGVjdGlvbnMsIERhdGVGYWN0b3J5LCB0eXBlLCAkcm9vdFNjb3BlLCAkc3RhdGVQYXJhbXMpIHtcblxuICAgIGNvbnN0IGFnZWQgPSBjb2xsZWN0aW9uc1swXTtcbiAgICBjb25zdCBmdXR1cmUgPSBjb2xsZWN0aW9uc1sxXTtcbiAgICBsZXQgaW5kZXggPSBhZ2VkLmxlbmd0aDtcblxuICAgIG5ldzYoMCk7XG5cbiAgICBpZiAoJHN0YXRlUGFyYW1zLnNlYXJjaCkge1xuICAgICAgICBsZXQgc2VhcmNoID0gJHN0YXRlUGFyYW1zLnNlYXJjaDtcbiAgICAgICAgbGV0IGRpZmYgPSBEYXRlRmFjdG9yeS5kaWZmcyhzZWFyY2gsIERhdGVGYWN0b3J5Lnllc3RlcmRheSwgdHlwZSk7XG4gICAgICAgIGlmIChkaWZmID49IDApIHNlYXJjaCA9IGluZGV4ICsgZGlmZjtcbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBzZWFyY2ggPSBhZ2VkLmZpbmQoaSA9PiBpLnRpdGxlID09PSBzZWFyY2gpO1xuICAgICAgICAgICAgaWYgKCFzZWFyY2gpIHtcbiAgICAgICAgICAgICAgICBzZWFyY2ggPSBEYXRlRmFjdG9yeS5kaXNwbGF5KGRpZmYsIHR5cGUpWzBdO1xuICAgICAgICAgICAgICAgIGFnZWQucHVzaChzZWFyY2gpO1xuICAgICAgICAgICAgICAgIGFnZWQuc29ydChEYXRlRmFjdG9yeS5jaHJvbm9Tb3J0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHNlYXJjaCA9IGFnZWQuaW5kZXhPZihzZWFyY2gpO1xuICAgICAgICB9XG4gICAgICAgIGluZGV4ID0gZmluZEluZGV4KHNlYXJjaCk7XG4gICAgICAgIGZ1bmN0aW9uIGZpbmRJbmRleChpKSB7XG4gICAgICAgICAgICByZXR1cm4gYWdlZC5sZW5ndGggLSBNYXRoLmNlaWwoKGFnZWQubGVuZ3RoIC0gaSkgLyA2KSAqIDY7XG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgfSBlbHNlIGlmICgkc3RhdGVQYXJhbXMuaW5kZXgpIGluZGV4ID0gKyRzdGF0ZVBhcmFtcy5pbmRleDtcbiAgICBpZiAoaW5kZXggPCAwKSAkc2NvcGUuY29sbGVjdGlvbnMgPSBhZ2VkLnNsaWNlKDAsIGluZGV4ICsgNik7XG4gICAgZWxzZSBuYXZpZ2F0ZSgpO1xuXG4gICAgZnVuY3Rpb24gbmV3NihvZmZzZXQpIHtcbiAgICAgICAgJHNjb3BlLmNvbGxlY3Rpb25zID0gW107XG5cbiAgICAgICAgRGF0ZUZhY3RvcnkuZGlzcGxheShvZmZzZXQsIHR5cGUpLmZvckVhY2goKGMpID0+IHtcbiAgICAgICAgICAgIGxldCB1c2UgPSBmdXR1cmUuZmluZChlbCA9PiBlbC50aXRsZSA9PT0gYy50aXRsZSkgfHwgYztcbiAgICAgICAgICAgICRzY29wZS5jb2xsZWN0aW9ucy5wdXNoKHVzZSk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgICRzY29wZS50aXRsZSA9ICgodHlwZSA9PT0gJ2RheScpID8gJ0RBSUxZJyA6ICdGVVRVUkUnKSArICcgTE9HJztcblxuICAgICRzY29wZS5wcmV2NiA9IGZ1bmN0aW9uKCkge1xuICAgICAgICBpZiAoaW5kZXggPD0gMCkgcmV0dXJuO1xuICAgICAgICBpZiAoaW5kZXggPCA2KSB7XG4gICAgICAgICAgICAkc2NvcGUuY29sbGVjdGlvbnMgPSBhZ2VkLnNsaWNlKDAsIGluZGV4KTtcbiAgICAgICAgICAgIGluZGV4IC09IDY7XG4gICAgICAgICAgICAkcm9vdFNjb3BlLiRicm9hZGNhc3QoJ3BhZ2VDaGFuZ2UnLCB7IGluZGV4OiBpbmRleCwgdHlwZTogdHlwZSB9KVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaW5kZXggLT0gNjtcbiAgICAgICAgICAgIG5hdmlnYXRlKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAkc2NvcGUubmV4dDYgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgaW5kZXggKz0gNjtcbiAgICAgICAgbmF2aWdhdGUoKTtcbiAgICB9XG5cbiAgICBmdW5jdGlvbiBuYXZpZ2F0ZSgpIHtcbiAgICAgICAgJHJvb3RTY29wZS4kYnJvYWRjYXN0KCdwYWdlQ2hhbmdlJywgeyBpbmRleDogaW5kZXgsIHR5cGU6IHR5cGUgfSlcbiAgICAgICAgaWYgKGluZGV4ID49IGFnZWQubGVuZ3RoKSBuZXc2KGluZGV4IC0gYWdlZC5sZW5ndGgpO1xuICAgICAgICBlbHNlICRzY29wZS5jb2xsZWN0aW9ucyA9IGFnZWQuc2xpY2UoaW5kZXgsIGluZGV4ICsgNik7XG4gICAgfVxuXG59KTtcbiIsIi8qanNoaW50IGVzdmVyc2lvbjogNiovXG5idWxsZXRBcHAuZGlyZWN0aXZlKCdtb250aENhbCcsIGZ1bmN0aW9uKCRsb2csICRzdGF0ZSkge1xuICAgIHJldHVybiB7XG4gICAgICAgIHJlc3RyaWN0OiAnRScsXG4gICAgICAgIHRlbXBsYXRlVXJsOiAnc2NyaXB0cy9tb250aC1jYWwvbW9udGguY2FsLnRlbXBsYXRlLmh0bWwnLFxuICAgICAgICBzY29wZToge1xuICAgICAgICAgICAgY29sbGVjdGlvbjogJz0nLFxuICAgICAgICAgICAgZGF5czogJz0nLFxuICAgICAgICB9LFxuICAgICAgICBsaW5rOiBmdW5jdGlvbihzY29wZSkge1xuICAgICAgICAgICAgc2NvcGUuZm9ybWF0dGVkVGl0bGUgPSAnQ2FsZW5kYXInOyAvL01vbWVudChzY29wZS5jb2xsZWN0aW9uLnRpdGxlKS5mb3JtYXQoJ01NTU0gWVlZWScpLnRvVXBwZXJDYXNlKCk7XG5cbiAgICAgICAgICAgIGdlbmVyYXRlQnVsbGV0TGlzdCgpXG5cbiAgICAgICAgICAgIGZ1bmN0aW9uIGdlbmVyYXRlQnVsbGV0TGlzdCAoKSB7XG4gICAgICAgICAgICAgIHNjb3BlLmJ1bGxldExpc3QgPSBzY29wZS5kYXlzLm1hcChkYXkgPT4ge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIHNjb3BlLmNvbGxlY3Rpb24uYnVsbGV0cy5maW5kKGJ1bGxldCA9PiBidWxsZXQuZGF0ZSA9PT0gZGF5KSB8fCBuZXcgQnVsbGV0LkV2ZW50KHtcbiAgICAgICAgICAgICAgICAgICAgICBkYXRlOiBkYXlcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBzY29wZS5yZW1vdmVCdWxsZXQgPSBmdW5jdGlvbihidWxsZXQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gc2NvcGUuY29sbGVjdGlvbi5yZW1vdmVCdWxsZXQoYnVsbGV0KVxuICAgICAgICAgICAgICAgIC50aGVuKCgpID0+IHtcbiAgICAgICAgICAgICAgICAgIGlmIChidWxsZXQuaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgZ2VuZXJhdGVCdWxsZXRMaXN0KClcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIHNjb3BlLiRldmFsQXN5bmMoKVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgLmNhdGNoKCRsb2cuZXJyKTtcbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIHNjb3BlLmFkZEJ1bGxldCA9IGZ1bmN0aW9uKGJ1bGxldCkge1xuICAgICAgICAgICAgICAgIGlmIChidWxsZXQuY29udGVudCAmJiBidWxsZXQuY29udGVudC5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgIHNjb3BlLmNvbGxlY3Rpb24uYWRkTW92ZWRCdWxsZXQoYnVsbGV0KTtcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbn0pO1xuIiwiLypqc2hpbnQgZXN2ZXJzaW9uOiA2Ki9cblxuYnVsbGV0QXBwLmNvbnRyb2xsZXIoJ01vbnRobHlUcmFja2VyQ3RybCcsIGZ1bmN0aW9uICgkc2NvcGUsIGNvbGxlY3Rpb25zLCBEYXRlRmFjdG9yeSwgbW9udGgsICRzdGF0ZSkge1xuXG4gICAgJHNjb3BlLmRheXNJbk1vbnRoID0gRGF0ZUZhY3RvcnkubW9udGhDYWwobW9udGgpO1xuICAgICRzY29wZS5tb250aCA9IG1vbnRoO1xuICAgICRzY29wZS5sb2cgPSBjb2xsZWN0aW9ucy5maW5kKGkgPT4gaS50eXBlID09PSBcIm1vbnRoXCIpIHx8IG5ldyBDb2xsZWN0aW9uKG1vbnRoLCAnbW9udGgnKTtcbiAgICAkc2NvcGUuY2FsID0gY29sbGVjdGlvbnMuZmluZChpID0+IGkudHlwZSA9PT0gXCJtb250aC1jYWxcIikgfHwgbmV3IENvbGxlY3Rpb24obW9udGgsICdtb250aC1jYWwnKTtcbiAgICAkc2NvcGUuZnV0dXJlID0gY29sbGVjdGlvbnMuZmluZChpID0+IGkudHlwZSA9PT0gXCJmdXR1cmVcIikgfHwgbmV3IENvbGxlY3Rpb24obW9udGgsICdmdXR1cmUnKTtcblxuICAgIC8vXG4gICAgJHNjb3BlLm5leHRNb250aCA9IGZ1bmN0aW9uKCkge1xuICAgICAgJHN0YXRlLmdvKCRzdGF0ZS5jdXJyZW50LCB7c2VhcmNoOiBEYXRlRmFjdG9yeS5uZXh0TW9udGgoJHNjb3BlLm1vbnRoKX0pXG4gICAgfVxuICAgICRzY29wZS5sYXN0TW9udGggPSBmdW5jdGlvbigpIHtcbiAgICAgICRzdGF0ZS5nbygkc3RhdGUuY3VycmVudCwge3NlYXJjaDogRGF0ZUZhY3RvcnkubGFzdE1vbnRoKCRzY29wZS5tb250aCl9KVxuICAgIH1cbn0pO1xuIiwiYnVsbGV0QXBwLmNvbmZpZyhmdW5jdGlvbigkc3RhdGVQcm92aWRlcikge1xuICAkc3RhdGVQcm92aWRlci5zdGF0ZSgnbW9udGgnLCB7XG4gICAgdXJsOiAnL21vbnRoLzpzZWFyY2gnLFxuICAgIHRlbXBsYXRlVXJsOiAnc2NyaXB0cy9tb250aGx5dHJhY2tlci9tb250aGx5dHJhY2tlci50ZW1wbGF0ZS5odG1sJyxcbiAgICBjb250cm9sbGVyOiAnTW9udGhseVRyYWNrZXJDdHJsJyxcbiAgICByZXNvbHZlOiB7XG4gICAgICBjb2xsZWN0aW9uczogZnVuY3Rpb24oJHN0YXRlUGFyYW1zLCBEYXRlRmFjdG9yeSkge1xuICAgICAgICBjb25zdCBtb250aFN0cmluZyA9ICRzdGF0ZVBhcmFtcy5zZWFyY2ggfHwgRGF0ZUZhY3Rvcnkucm91bmRNb250aChuZXcgRGF0ZSkudG9JU09TdHJpbmcoKTtcbiAgICAgICAgcmV0dXJuIENvbGxlY3Rpb24uZmV0Y2hBbGwoe3RpdGxlOiBtb250aFN0cmluZ30pO1xuICAgICAgfSxcbiAgICAgIG1vbnRoOiBmdW5jdGlvbigkc3RhdGVQYXJhbXMsIERhdGVGYWN0b3J5KSB7XG4gICAgICAgIHJldHVybiAkc3RhdGVQYXJhbXMuc2VhcmNoIHx8IERhdGVGYWN0b3J5LnRoaXNNb250aDtcbiAgICAgIH1cbiAgICB9XG4gIH0pXG59KVxuIiwiYnVsbGV0QXBwLmRpcmVjdGl2ZSgncmVmcmVzaCcsIGZ1bmN0aW9uKCRzdGF0ZSwgJHJvb3RTY29wZSwgQXV0aEZhY3Rvcnkpe1xuICAgIHJldHVybiB7XG4gICAgICAgIHJlc3RyaWN0OiAnQScsXG4gICAgICAgIGxpbms6IGZ1bmN0aW9uKHNjb3BlLCBlbGVtZW50KSB7XG5cbiAgICAgICAgICAgIHJlbW90ZURCLmdldFNlc3Npb24oKVxuICAgICAgICAgICAgLnRoZW4ocmVzID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB1c2VybmFtZSA9IHJlcy51c2VyQ3R4Lm5hbWU7XG4gICAgICAgICAgICAgICAgaWYodXNlcm5hbWUpIHtcbiAgICAgICAgICAgICAgICAgICAgJHJvb3RTY29wZS4kYXBwbHkoZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICRyb290U2NvcGUudXNlciA9IHVzZXJuYW1lO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgQXV0aEZhY3Rvcnkuc3luY0RCKHVzZXJuYW1lKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAuY2F0Y2goY29uc29sZS5lcnJvci5iaW5kKGNvbnNvbGUpKVxuXG4gICAgICAgICAgICBzY29wZS5zeW5jaW5nID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuICRyb290U2NvcGUuc3luYztcbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIHNjb3BlLmxvZ2luID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgaWYoISRyb290U2NvcGUudXNlcikgJHN0YXRlLmdvKCdzaWdudXAnKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICB9O1xufSk7XG4iLCJidWxsZXRBcHAuZGlyZWN0aXZlKCdzZWFyY2hCYXInLCBmdW5jdGlvbihjdXJyZW50U3RhdGVzLCAkc3RhdGUsICRsb2csICRmaWx0ZXIpIHtcbiAgICByZXR1cm4ge1xuICAgICAgICByZXN0cmljdDogJ0UnLFxuICAgICAgICB0ZW1wbGF0ZVVybDogJ3NjcmlwdHMvc2VhcmNoL3NlYXJjaC50ZW1wbGF0ZS5odG1sJyxcbiAgICAgICAgbGluazogZnVuY3Rpb24oc2NvcGUsIGVsZW1lbnQpIHtcbiAgICAgICAgICAgIGxldCBmZXRjaGVkO1xuXG4gICAgICAgICAgICBzY29wZS5nZXRCdWxsZXRzID0gZnVuY3Rpb24oc2VhcmNoKSB7XG4gICAgICAgICAgICAgICAgaWYgKGZldGNoZWQpIHJldHVybiBmZXRjaGVkLmZpbHRlcihiID0+IGIuY29udGVudC5pbmNsdWRlcyhzZWFyY2gpKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gQnVsbGV0LmZldGNoV2l0aENvbGxlY3Rpb25zKHNlYXJjaClcbiAgICAgICAgICAgICAgICAgICAgLnRoZW4oYiA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmZXRjaGVkID0gYjtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmZXRjaGVkO1xuICAgICAgICAgICAgICAgICAgICB9KTsgXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHNjb3BlLmdvID0gZnVuY3Rpb24oaXRlbSkge1xuICAgICAgICAgICAgICAgIGlmIChpdGVtLmNvbGxlY3Rpb25zLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgICAgICBsZXQgY29sbGVjdGlvbiA9IGl0ZW0uY29sbGVjdGlvbnNbMF07XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb2xsZWN0aW9uLnR5cGU9PT0nZ2VuZXJpYycpICRzdGF0ZS5nbygnZ2VuZXJpYycsIHtpZDogY29sbGVjdGlvbi5pZH0pO1xuICAgICAgICAgICAgICAgICAgICBlbHNlICRzdGF0ZS5nbygkZmlsdGVyKCdzdGF0ZU5hbWUnKShjb2xsZWN0aW9uLnR5cGUpLCB7IHNlYXJjaDogY29sbGVjdGlvbi50aXRsZSB9KVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlICRzdGF0ZS5nbygnaW5kZXgnKTtcbiAgICAgICAgICAgICAgICBmZXRjaGVkID0gbnVsbDtcbiAgICAgICAgICAgICAgICBzY29wZS5zZWxlY3QgPSBudWxsO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBlbGVtZW50Lm9uKCdrZXlkb3duJywgZnVuY3Rpb24oZSkge1xuICAgICAgICAgICAgICAgIGlmIChlLndoaWNoPT09MjcgfHwgZS53aGljaD09PTgpIHtcbiAgICAgICAgICAgICAgICAgICAgZmV0Y2hlZCA9IG51bGw7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSlcblxuICAgICAgICB9XG4gICAgfTtcbn0pO1xuIiwiLypqc2hpbnQgbm9kZTp0cnVlLCBlc3ZlcnNpb246NiovXG5idWxsZXRBcHAuZmFjdG9yeSgnQXV0aEZhY3RvcnknLCBmdW5jdGlvbiAoJHN0YXRlLCAkcm9vdFNjb3BlLCAkdGltZW91dCkge1xuXG4gICAgY29uc3QgQXV0aCA9IHt9O1xuXG4gICAgZnVuY3Rpb24gY3JlYXRlVXNlckRCKHVzZXIsIHZlcmIpIHtcbiAgICAgICAgbGV0IHVzZXJuYW1lID0gdXNlci5lbWFpbC5zcGxpdCgnQCcpWzBdO1xuICAgICAgICByZXR1cm4gcmVtb3RlREJbdmVyYl0odXNlcm5hbWUsIHVzZXIucGFzc3dvcmQpXG4gICAgICAgICAgICAudGhlbihyZXMgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlcyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHZlcmIgPT09ICdzaWdudXAnID8gQXV0aC5sb2dpbih1c2VyKSA6IHJlcztcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAudGhlbihyZXMgPT4ge1xuICAgICAgICAgICAgICAgICRyb290U2NvcGUuJGFwcGx5KGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgICAgICAgICRyb290U2NvcGUudXNlciA9IHJlcy5uYW1lO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKEF1dGguc3luY0RCKHVzZXJuYW1lKSk7XG4gICAgICAgICAgICAgICAgJHN0YXRlLmdvKCdpbmRleCcpXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLmNhdGNoKGVyciA9PiBjb25zb2xlLmVycm9yKFwiQ291bGRuJ3Qgc2lnbmluOiBcIiwgZXJyKSk7XG4gICAgfVxuXG4gICAgQXV0aC5zeW5jREIgPSBmdW5jdGlvbih1c2VybmFtZSkge1xuICAgICAgICByZW1vdGVEQiA9IG5ldyBQb3VjaERCKHJlbW90ZURCQWRkcmVzcyArIHVzZXJEQlVybCh1c2VybmFtZSksIHtcbiAgICAgICAgICAgIHNraXBTZXR1cDogdHJ1ZVxuICAgICAgICB9KTtcbiAgICAgICAgcmVtb3RlREIuY29tcGFjdCgpO1xuICAgICAgICByZXR1cm4gZGIuc3luYyhyZW1vdGVEQiwge1xuICAgICAgICAgICAgICAgIGxpdmU6IHRydWUsXG4gICAgICAgICAgICAgICAgcmV0cnk6IHRydWVcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAub24oJ2FjdGl2ZScsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAkcm9vdFNjb3BlLiRhcHBseShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICRyb290U2NvcGUuc3luYyA9IHRydWU7XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAub24oJ3BhdXNlZCcsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAkdGltZW91dChmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgJHJvb3RTY29wZS5zeW5jID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgfSwgNTAwKTtcbiAgICAgICAgICAgIH0pO1xuICAgIH1cblxuICAgIEF1dGgubG9naW4gPSBmdW5jdGlvbiAodXNlcikge1xuICAgICAgICByZXR1cm4gY3JlYXRlVXNlckRCKHVzZXIsICdsb2dpbicpO1xuICAgIH1cblxuICAgIEF1dGguc2lnbnVwID0gZnVuY3Rpb24gKHVzZXIpIHtcbiAgICAgICAgcmV0dXJuIGNyZWF0ZVVzZXJEQih1c2VyLCAnc2lnbnVwJyk7XG4gICAgfVxuXG4gICAgcmV0dXJuIEF1dGg7XG59KTtcbiIsImJ1bGxldEFwcC5jb250cm9sbGVyKCdzaWdudXBDdHJsJywgZnVuY3Rpb24oJHNjb3BlLCBBdXRoRmFjdG9yeSl7XG4gICAgYW5ndWxhci5leHRlbmQoJHNjb3BlLCBBdXRoRmFjdG9yeSk7XG59KTtcbiIsImJ1bGxldEFwcC5jb25maWcoZnVuY3Rpb24oJHN0YXRlUHJvdmlkZXIpIHtcblxuICAgICRzdGF0ZVByb3ZpZGVyLnN0YXRlKCdzaWdudXAnLCB7XG4gICAgICAgIHVybDogJy9zaWdudXAnLFxuICAgICAgICB0ZW1wbGF0ZVVybDogJ3NjcmlwdHMvc2lnbnVwL3NpZ251cC50ZW1wbGF0ZS5odG1sJyxcbiAgICAgICAgY29udHJvbGxlcjogJ3NpZ251cEN0cmwnXG4gICAgfSk7XG5cbn0pO1xuIl0sInNvdXJjZVJvb3QiOiIvc291cmNlLyJ9
